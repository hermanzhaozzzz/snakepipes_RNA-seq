# _*_ coding: UTF-8 _*_

### >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ###
###  Wu Hao
###  h_wu@stu.pku.edu.cn
###  2022-08-30 RNA editing RNA-seq analysis wrokflow snakemake v09
###  2022-09-07 Update: cuffdiff diff gene analysis v10
### >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ###


########################################################################
# Wu Hao
# 2022-10-24
# /lustre2/chengqiyi_pkuhpc/wuhao/02.Projects/02.Rewrite_RNA_edit/83.20221013_C2U_MiniACBE_RNA-seq
######################################################################## 
# run on abyss
# /lustre2/chengqiyi_pkuhpc/wuhao/02.Projects/02.Rewrite_RNA_edit/83.20221013_C2U_MiniACBE_RNA-seq


### ================================================================ ###
###                              Pipeline                            ###
### ================================================================ ###
# 1. fastqc and multiqc rawdata
# 2. rm adapter with trim_galore
# 3. trim fastq rm rRNA reads
# 4. STAR mapping
# 5. BAM add RG tag
# 6. BAM sort
# 7. BAM rm dup
# 8. BAM quality Q20 and Filt Clips
# 9. BAM index
# 10. BAM stats
# 11. Cover depth stats
# 12. Conprehensive QC report
# 13. BAM to mpileup (if known some region add -l region.bed, else rm -l param)
# 14. mpileup to bmat
# 15. bmat filt
# 16. filt bmat to pmat
# 17. pmat rmSNP
# 18. Extract contain mut sites
# 19. Treat rm Ctrl sites
# 20. Ctrl rm Treat sites
# 21. Cases jitter and mutheat plots
# 22. Get RNA status
# 23. Motif plots
# 24. Multiple motif barplot
# 25. Homer annotation
# 26. Filt homer anno stats
# 27. Homer anno stack barplot
# 28. samtools extract bam
# 29. bam sort and idx
# 30. RSeQC anno above bam
# 31. Filt RSeQC anno
# 32. RSeQC anno stack barplot
# ... ...

### ================================================================ ###
###                              Programs                            ###
### ================================================================ ###
PICARD = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/pkgs/picard-3.4.0-hdfd78af_0/share/picard-3.4.0-0/picard.jar"
BISMARK = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/bismark"
CUTADAPT = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/cutadapt"
BWA = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/bwa"
SAMTOOLS = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/samtools"
SAMCLIP = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/samclip"
PYTHON = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/envs/whpy27/bin/python"
PYTHON3 = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/python"
BEDTOOLS = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/bedtools"
JAVA = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/envs/Java8/bin/java"
BOWTIE2 = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/bowtie2"
STAR = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/STAR" # index were builded with v2.7.1a
FASTQC = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/fastqc"
MULTIQC = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/multiqc"
TRIM_GALORE = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/trim_galore"
RSCRIPT = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/envs/R4.1.3/bin/Rscript"
READFQ = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/readfq"

ANNOTATE_PEAK = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/annotatePeaks.pl"
CUFFDIFF = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/envs/cufflinks/bin/cuffdiff"

# READ_DISTRIBUTION = "/home/wuhao/wuhao_HD/miniconda3/bin/read_distribution.py"
READ_DISTRIBUTION = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/envs/whpy27/bin/read_distribution.py"
SAMBAMBA = "/lustre2/chengqiyi_pkuhpc/wuhao/miniforge3/bin/sambamba"

GATK38 = "/lustre2/chengqiyi_pkuhpc/wuhao/01.Biosoft/GenomeAnalysisTK-3.8-1-0/GenomeAnalysisTK.jar" 
GATK40 = "/lustre2/chengqiyi_pkuhpc/wuhao/01.Biosoft/gatk-4.0.12.0/gatk-package-4.0.12.0-local.jar" 

### ================================================================ ###
###                              Index                               ###
### ================================================================ ###
BWA_HG38_IDX = "/lustre2/chengqiyi_pkuhpc/wuhao/00.Index_and_DB/align_index/hg38/bwa/hg38_only_chromosome.fa"
BWA_HG38_FAI = "/lustre2/chengqiyi_pkuhpc/wuhao/00.Index_and_DB/align_index/hg38/bwa/hg38_only_chromosome.fa.fai"
HG38_JSON = "/lustre2/chengqiyi_pkuhpc/wuhao/00.Index_and_DB/align_index/hg38/hg38.json"
HG38_REFSEQ_BED = "/lustre2/chengqiyi_pkuhpc/wuhao/00.Index_and_DB/annotation_files/RSeQC_bed/hg38_RefSeq.bed"
SNP_VCF = "/lustre2/chengqiyi_pkuhpc/wuhao/00.Index_and_DB/mutation_files/293T/293T-Mock-Input-covaris_bwa_hg38_sort_rmdup.recall.merge.Genotype.filter.rmdup_signal.vcf"

HG38_GTF = "/lustre2/chengqiyi_pkuhpc/wuhao/00.Index_and_DB/align_index/hg38/hg38_refseq_from_ucsc.rm_XM_XR.fix_name.gtf"

HG38_FA_DICT = "/lustre2/chengqiyi_pkuhpc/wuhao/00.Index_and_DB/align_index/hg38/bwa/hg38_only_chromosome.fa"

# INDEL_VCF = "/home/wuhao/wuhao_HD/align_index/vcf_files/293T-All_sample-bismark_hg38_sort_rmdup.BCFCall.INDEL.vcf.gz"
# REF_VCF = "/home/wuhao/wuhao_HD/GATK_bundle/hg38/dbsnp_146.hg38.vcf.gz"

STAR_HG38_INDEX = "/lustre2/chengqiyi_pkuhpc/wuhao/00.Index_and_DB/align_index/hg38/STAR"

rRNA_IDX = "/lustre2/chengqiyi_pkuhpc/wuhao/00.Index_and_DB/align_index/human_rRNA/rRNA"
# HG38_REFSEQ_BED = "/home/wuhao/wuhao_HD/annotations/RSeQC/hg38_RefSeq.bed"


### ================================================================ ###
###                              Samples                             ###
### ================================================================ ###
SAMPLES = [
    
    "Evector",
    "LELvector",
    
    "PG82S",
    "PG82S-1",
    "PR82S",
    "PR82T",
    "CG82T",
    "CH82T"
    
]

SAMPLES_LEVEL = ",".join(SAMPLES)

COLORS = [
    "1976d2",
    "90be6d",
    "4a4e69",
    "5f0f40",
    "f9844a",
    "f8961e",
    "f94144",
    "1b4332"
]
SAMPLES_COLOR = ",".join(COLORS)
# BAM_SAMPLES = ["../3.Process/02.STAR_bam/"+i+"_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam" for i in SAMPLES]
# Quantify_bams = " ".join(BAM_SAMPLES)

### remember to compare TREATs with their corresponding CRTLs ! ###
TREAT_SAMPLES_1 = [
    "PG82S",
    "PG82S-1",
    "PR82S",
    "PR82T",
    "CG82T",
    "CH82T"
]
TREAT_SAMPLES_2 = [
    
]
# TREAT_ls = ["../3.Process/05.pmat/"+i+"_SMART_rmSNP_mut_Add_Pval_Qval.pmat" for i in TREAT_SAMPLES]

CTRL_SAMPLES_1 = [
    "Evector",
    "LELvector"
]
CTRL_SAMPLES_2 = [
    
]
# CTRL_ls = ["../3.Process/05.pmat/"+i+"_SMART_rmSNP_mut_Add_Pval_Qval.pmat" for i in CTRL_SAMPLES]
    
    
### use for need last task output don, and this rule input is expand() type
def Get_sample_name(path, case, file_suffix):
    if path[-1] == "/":
        pre = path
    else:
        pre = path + "/"
    file_name = pre + case + file_suffix
    return file_name

import pandas as pd
import statistics    

def Get_Downsample_Scale(multiqc_stats_file):
    stats = multiqc_stats_file

    df = pd.read_csv(stats,encoding = "gbk",engine = "python",sep = "\t")
    reads_size = list(df["Samtools_mqc-generalstats-samtools-raw_total_sequences"])
    mean = statistics.mean(reads_size)
    median = statistics.median(reads_size)
    min_v = min(reads_size)

    down_to_size = int(min_v/1000000)*1000000
    
    return down_to_size
    
# ../3.Process/05.pmat/{treat_sample}_Aligned_sort_MarkDup_rmdup_MAPQ20_rmSNP.pmat
# ctrl_samples = lambda wildcards, input: Get_samples_str(input[0], "_Aligned"+input[0].split("_Aligned")[1], Samples_crrelation[input[0].split("_Aligned")[0].split("/")[-1]])
# "../3.Process/06.filt_pmat/{sample}_SMART_rmSNP_mut_fix_cases.pmat"
def Get_samples_str(path,suffix,sample_ls):
    if path[-1] == "/":
        file_path = path
    else:
        file_path = path+"/"
    samples_path = ["".join([file_path,i,suffix]) for i in sample_ls]
    samples_str = " ".join(samples_path)
    return samples_str

Samples_crrelation ={ 
    
    "Evector" : TREAT_SAMPLES_1,
    "LELvector" : TREAT_SAMPLES_1,
    
    "PG82S" : CTRL_SAMPLES_1,
    "PG82S-1" : CTRL_SAMPLES_1,
    "PR82S" : CTRL_SAMPLES_1,
    "PR82T" : CTRL_SAMPLES_1,
    "CG82T" : CTRL_SAMPLES_1,
    "CH82T" : CTRL_SAMPLES_1
}

### ================================================================ ###
###                              Cutoffs                             ###
### ================================================================ ###
STACK_BARPLOT_COLORS_Homer = [
    "90be6d","f9c74f","f9844a","f8961e","48cae4",
    "f94144","bc6c25","dda15e","606c38","9e2a2b",
    "5f0f40","e56b6f","eaac8b"
]
STACK_BARPLOT_COLORS_STR_HOMER = ",".join(STACK_BARPLOT_COLORS_Homer)

STACK_BARPLOT_COLORS_RSeQC = [
    "e76f51","e9c46a","264653",
    "2a9d8f","457b9d","b5179e"
]
STACK_BARPLOT_COLORS_STR_RSEQC= ",".join(STACK_BARPLOT_COLORS_RSeQC)

READ_IDX = ["1","2"]

## for AG:TC and CT:GA
FWD_MUT_d = ["AG","CT"]
REV_MUT_d = ["TC","GA"]

MUT_COMBINE = ",".join([i+"-"+j for i,j in zip(FWD_MUT_d,REV_MUT_d)])
MUT_COMBINE_f = [i+"_"+j for i,j in zip(FWD_MUT_d,REV_MUT_d)]
MUT_CORR = dict(zip(FWD_MUT_d,REV_MUT_d))

FWD, REV = MUT_COMBINE_f[0:2]

# get_rna_split_str = "filter"
get_rna_split_str = "_rm_low_cover"
KEY_STR = [i+"_"+j+get_rna_split_str for i,j in zip(FWD_MUT_d,REV_MUT_d)]

# MUT_COUNT = ["3","5","8","10"]
MUT_COUNT = ["6"]
# COVER_COUNT = ["20"]
COVER_COUNT = ["30"]
MUT_RATIO = ["0"]
# MAX_COVER = ["Unlimited","100"]
# MAX_COVER = ["Unlimited"]
QVALUE_CUTOFF = ["0.001"]

LEFT_EXTEND = ["2"]
RIGHT_EXTEND = ["4"]

RATIO_REGION = [
    # "0-1",
    # "0-50",
    # "1-10",
    # "10-50",
    # "50-100",
    "0-100"
]

# RM_CTRL_TYPE = ["all"]
# RM_CTRL_TYPE = ["paired"]


### ================================================================ ###
###                             Main rules                           ###
### ================================================================ ###

rule all:
    input:
        ### rm rRNA and adapter ###
        expand("../1.Rawdata/rawdata/{sample}_R{read_idx}.fastq.gz",sample=SAMPLES,read_idx=READ_IDX),
        "../3.Process/00.MultiQC/01.Raw_fq_MultiQC",
        expand("../3.Process/01.fix_fastq/{sample}_R{read_idx}_val_{read_idx}.fq.gz",sample=SAMPLES,read_idx=READ_IDX),
        "../3.Process/00.MultiQC/02.Trim_galore_MultiQC/Trim_Galore",
        "../3.Process/00.MultiQC/02.Trim_galore_MultiQC/MultiQC",
        expand("../3.Process/01.fix_fastq/{sample}_rm_rRNA.fq.{read_idx}.gz",sample=SAMPLES,read_idx=READ_IDX),
        expand("../3.Process/01.fix_fastq/{sample}_Map2rRNA_stats.txt",sample=SAMPLES),
        "../3.Process/00.MultiQC/03.Rm_rRNA_MultiQC/MultiQC",
        ### STAR align and deal BAM ###
        expand("../3.Process/02.STAR_bam/{sample}_Aligned.out.bam",sample=SAMPLES),
        expand("../3.Process/02.STAR_bam/{sample}_Log.final.out",sample=SAMPLES),
        "../3.Process/00.MultiQC/04.STAR_align_BAM_MultiQC",
        expand("../3.Process/02.STAR_bam/{sample}_Aligned.out.fix_RG.bam",sample=SAMPLES),
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam",sample=SAMPLES),
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam.bai",sample=SAMPLES),
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam.mapping_stats",sample=SAMPLES),
        "../3.Process/00.MultiQC/05.Sort_BAM_MultiQC",
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup.bam",sample=SAMPLES),
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup.matrix",sample=SAMPLES),
        "../3.Process/00.MultiQC/06.Rmdup_MultiQC",
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam",sample=SAMPLES),
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam.bai",sample=SAMPLES),
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam.mapping_stats",sample=SAMPLES),
        "../3.Process/00.MultiQC/07.Final_BAM_MultiQC",
        expand("../3.Process/00.MultiQC/07.Final_BAM_MultiQC/multiqc_general_stats.txt"),
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam",sample=SAMPLES),
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam.bai",sample=SAMPLES),
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam.mapping_stats",sample=SAMPLES),
        "../3.Process/00.MultiQC/08.Downsample_BAM_MultiQC",
        ### Bam -> Mpileup -> Bmat -> pmat ###
        expand("../3.Process/03.mpileup/{sample}_Aligned_sort_MarkDup_rmdup.mpileup",sample=SAMPLES),
        expand("../3.Process/04.bmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20.bmat",sample=SAMPLES),
        expand("../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20.pmat",sample=SAMPLES),
        expand("../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20_rmSNP.pmat",sample=SAMPLES),
        expand("../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20_rmSNP_mut.pmat",sample=SAMPLES),
        expand("../3.Process/05.pmat/{sample}_SMART_rmSNP_mut_Add_Pval_Qval.pmat",sample=SAMPLES),
        expand("../3.Process/06.filt_pmat/{sample}_SMART_rmSNP_mut_fix_cases.pmat",sample=SAMPLES),
        # ### pmat -> cutoff file, jitter, mutheat ###
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot.pdf",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF),
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Mutheatplot.pdf",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF),
        # expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_filter.txt",
        #       mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES,mut_ls=MUT_COMBINE_f),
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES,mut_ls=MUT_COMBINE_f),
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_low_cover_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot_{mut_ls}.pdf",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES,mut_ls=MUT_COMBINE_f),
        ### Get RNA seq, motif status and plot ###
        expand("../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_Extend_l{left_extend}r{right_extend}_RNA.txt",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_filter.txt",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/Extend_sites_motifs.pdf",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/Codon_sites_motif.pdf",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/Multiple_RNA_status.pdf",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        ### Homer annotation and plots ###
        expand("../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_anno.txt",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_anno.stats",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_anno_filt.stats",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/R_{ratio_region}_stack_barplot.pdf",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        ### RSeQC annotation and plots ###
        expand("../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_region_R_{ratio_region}.bam",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_region_R_{ratio_region}_sort.bam",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_region_R_{ratio_region}_sort.bam.bai",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_RSeQC_anno.txt",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_RSeQC_anno_filt.txt",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        expand("../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/RSeQC_R_{ratio_region}_stackbar.pdf",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        ### downstream analysis ###
        # venn plot #
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{treat_sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,mut_ls=MUT_COMBINE_f,treat_sample=SAMPLES),
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{ctrl_sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,mut_ls=MUT_COMBINE_f,ctrl_sample=SAMPLES),
        expand("../3.Process/10.Venn_plots/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{treat_sample}_vs_{ctrl_sample}_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}_{mut_ls}_venn.pdf",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,treat_sample=SAMPLES,ctrl_sample=SAMPLES,mut_ls=MUT_COMBINE_f),
        # specific and overlap motif #
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample1}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample1=SAMPLES,mut_ls=MUT_COMBINE_f),
        expand("../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_ls}_rm_low_cover/{sample1}_Extend_l{left_extend}r{right_extend}_RNA.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample1=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_ls=MUT_COMBINE_f),
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample2}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample2=SAMPLES,mut_ls=MUT_COMBINE_f),
        expand("../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_ls}_rm_low_cover/{sample2}_Extend_l{left_extend}r{right_extend}_RNA.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample2=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_ls=MUT_COMBINE_f),
        expand("../3.Process/11.Motif_sprcific/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_ls}_rm_low_cover/{sample1}_vs_{sample2}/{sample1}_vs_{sample2}_{mut_ls}_overlap_and_specific_motif.pdf",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample1=SAMPLES,sample2=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_ls=MUT_COMBINE_f),
        ### Other mutation heatmap ###
        # expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_filter_other_mut.txt",
        #        mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES),
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_other_mut_rm_low.txt",
               mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES),
        expand("../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_rm_low_cover_merge.txt",
               mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES),
        expand("../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_rm_low_cover_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot.pdf",
               mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF),
        expand("../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_rm_low_cover_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Mutheatplot.pdf",
               mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF),
        ### Diff gene expression analysis ###
        expand("../3.Process/02.STAR_bam/{deg_treat_sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam",deg_treat_sample=TREAT_SAMPLES_1),
        expand("../3.Process/02.STAR_bam/{deg_ctrl_sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam",deg_ctrl_sample=CTRL_SAMPLES_1),
        expand("../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}/{deg_treat_sample}_vs_{deg_ctrl_sample}_cuffdiff.log",deg_treat_sample=TREAT_SAMPLES_1,deg_ctrl_sample=CTRL_SAMPLES_1),
        expand("../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}/Cuffdiff_plot_volcano.log",deg_treat_sample=TREAT_SAMPLES_1,deg_ctrl_sample=CTRL_SAMPLES_1),
        expand("../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}/Cuffdiff_{deg_treat_sample}_vs_{deg_ctrl_sample}_scatter.pdf",deg_treat_sample=TREAT_SAMPLES_1,deg_ctrl_sample=CTRL_SAMPLES_1)
        # expand("../3.Process/02.STAR_bam/{treat_sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam",treat_sample=TREAT_SAMPLES_1),
        # expand("../3.Process/02.STAR_bam/{ctrl_sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam",ctrl_sample=CTRL_SAMPLES_1),
        # expand("../3.Process/09.Cuffdiff_gene/{treat_sample}_vs_{ctrl_sample}/{treat_sample}_vs_{ctrl_sample}_cuffdiff.log",treat_sample=TREAT_SAMPLES_1,ctrl_sample=CTRL_SAMPLES_1),
        # expand("../3.Process/09.Cuffdiff_gene/{treat_sample}_vs_{ctrl_sample}/Cuffdiff_plot_volcano.log",treat_sample=TREAT_SAMPLES_1,ctrl_sample=CTRL_SAMPLES_1),
        # expand("../3.Process/09.Cuffdiff_gene/{treat_sample}_vs_{ctrl_sample}/Cuffdiff_{treat_sample}_vs_{ctrl_sample}_scatter.pdf",treat_sample=TREAT_SAMPLES_1,ctrl_sample=CTRL_SAMPLES_1)

        
rule A01_FastQC:
    input:
        "../1.Rawdata/rawdata/{sample}_R1.fastq.gz",
        "../1.Rawdata/rawdata/{sample}_R2.fastq.gz"
    output:
        directory("../1.Rawdata/rawdata/FastQC/{sample}")
    log:
        "../1.Rawdata/rawdata/FastQC/{sample}/{sample}.fastqc.log"
    shell:
        """
        mkdir -p {output} && \
        {FASTQC} -o {output} -t 24 {input[0]} {input[1]} > {log} 2>&1
        """

        
rule A02_MultiQC: 
    input: 
        expand("../1.Rawdata/rawdata/FastQC/{sample}",sample=SAMPLES)
    output:
        directory("../3.Process/00.MultiQC/01.Raw_fq_MultiQC")
    log:
        "../3.Process/00.MultiQC/01.Raw_fq_MultiQC/Raw_fq_multiqc_report.html.log"
    shell: 
        """
        mkdir -p {output} && \
        {MULTIQC} {input} -o {output} -n Raw_fq_multiqc_report.html --no-data-dir > {log} 2>&1
        """

        
rule A03_Adapter_Trim_galore:
    input:
        "../1.Rawdata/rawdata/{sample}_R1.fastq.gz",
        "../1.Rawdata/rawdata/{sample}_R2.fastq.gz"
    output:
        "../3.Process/01.fix_fastq/{sample}_R1_val_1.fq.gz",
        "../3.Process/01.fix_fastq/{sample}_R2_val_2.fq.gz"
#         "../3.Process/01.fix_fastq/{sample}_1.fq.gz_trimming_report.txt",
#         "../3.Process/01.fix_fastq/{sample}_2.fq.gz_trimming_report.txt"
    log:
        "../3.Process/01.fix_fastq/{sample}_trim_galore.log"
    shell:
        "{TRIM_GALORE} -q 20 --phred33 --stringency 3 \
        --length 20 -o ../3.Process/01.fix_fastq -j 24 \
        --paired {input[0]} {input[1]} > {log} 2>&1 "
        
        
rule A04_Trim_Galore_log_MultiQC: 
    input: 
        expand("../3.Process/01.fix_fastq/{sample}_trim_galore.log",sample=SAMPLES)
    output:
        directory("../3.Process/00.MultiQC/02.Trim_galore_MultiQC/Trim_Galore")
    log:
        "../3.Process/00.MultiQC/02.Trim_galore_MultiQC/Trim_Galore/Trim_Galore_multiqc_report.html.log"
    shell: 
        """
        mkdir -p {output} && \
        {MULTIQC} {input} -o {output} -n Trim_Galore_multiqc_report.html --no-data-dir > {log} 2>&1
        """
        
        
rule A05_Trim_fq_FastQC:
    input:
        "../3.Process/01.fix_fastq/{sample}_R1_val_1.fq.gz",
        "../3.Process/01.fix_fastq/{sample}_R2_val_2.fq.gz"
    output:
        directory("../3.Process/00.MultiQC/02.Trim_galore_MultiQC/FastQC/{sample}")
    log:
        "../3.Process/00.MultiQC/02.Trim_galore_MultiQC/FastQC/{sample}/{sample}.fastqc.log"
    shell:
        """
        mkdir -p {output} && \
        {FASTQC} -o {output} -t 24 {input[0]} {input[1]} > {log} 2>&1
        """

        
rule A06_Trim_fq_MultiQC: 
    input: 
        expand("../3.Process/00.MultiQC/02.Trim_galore_MultiQC/FastQC/{sample}",sample=SAMPLES)
    output:
        directory("../3.Process/00.MultiQC/02.Trim_galore_MultiQC/MultiQC")
    log:
        "../3.Process/00.MultiQC/02.Trim_galore_MultiQC/MultiQC/Trim_Fq_multiqc_report.html.log"
    shell: 
        """
        mkdir -p {output} && \
        {MULTIQC} {input} -o {output} -n Trim_Fq_multiqc_report.html --no-data-dir > {log} 2>&1
        """

        
rule A07_rm_rRNA:
    input:
        "../3.Process/01.fix_fastq/{sample}_R1_val_1.fq.gz",
        "../3.Process/01.fix_fastq/{sample}_R2_val_2.fq.gz"
    output:
        "../3.Process/01.fix_fastq/{sample}_rm_rRNA.fq.1.gz",
        "../3.Process/01.fix_fastq/{sample}_rm_rRNA.fq.2.gz",
        stat = "../3.Process/01.fix_fastq/{sample}_Map2rRNA_stats.txt"
    params:
        unmap_prefix = "../3.Process/01.fix_fastq/{sample}_rm_rRNA.fq.gz"
    shell:
        """
        {BOWTIE2} \
        --no-unal -I 1 -X 1000 -p 24 -x {rRNA_IDX} \
        -1 {input[0]} -2 {input[1]} \
        --un-conc-gz {params.unmap_prefix} > {output.stat} 2>&1
        """    


rule A08_STAR_mapping:
    input:
        fq1 = "../3.Process/01.fix_fastq/{sample}_rm_rRNA.fq.1.gz",
        fq2 = "../3.Process/01.fix_fastq/{sample}_rm_rRNA.fq.2.gz"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned.out.bam",
        "../3.Process/02.STAR_bam/{sample}_Log.final.out"
    log:
        "../3.Process/02.STAR_bam/{sample}_Aligned.out.log"
    params:
        "../3.Process/02.STAR_bam/{sample}_"
    shell:
        "{STAR} \
        --genomeDir {STAR_HG38_INDEX} \
        --runThreadN 24 \
        --readFilesIn {input.fq1} {input.fq2} \
        --readFilesCommand zcat \
        --outFileNamePrefix {params} \
        --outSAMtype BAM Unsorted \
        --outSAMstrandField intronMotif \
        --outFilterIntronMotifs RemoveNoncanonical > {log} 2>&1"


rule A09_add_RG_tag:
    input:
        "../3.Process/02.STAR_bam/{sample}_Aligned.out.bam"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned.out.fix_RG.bam"
    params:
        tag = "'@RG\\tID:{sample}\\tSM:{sample}\\tPL:ILLUMINA'"
    shell:
        "{SAMTOOLS} addreplacerg -r {params.tag} -@ 24 -O BAM -o {output} --reference {HG38_FA_DICT} {input}"


rule A10_BAM_sort_by_position:
    input:
        "../3.Process/02.STAR_bam/{sample}_Aligned.out.fix_RG.bam"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam"
    shell:
        # "{SAMTOOLS} sort -O BAM -o {output} -T {output}.temp -@ 24 -m 4G {input}"
        "{SAMTOOLS} sort -O BAM -o {output} {input}"
        

rule A11_Sort_idx:
    input:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam.bai"
    shell:
        """
        {SAMTOOLS} index -@ 24 {input} {output}
        """


rule A12_Sort_BAM_stats:
    input:
        bam = "../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam",
        bam_index = "../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam.bai"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam.mapping_stats"
    shell:
        """
        {SAMTOOLS} stats -@ 24 --reference {BWA_HG38_IDX} {input.bam} > {output}
        """
        

rule A13_rmdup:
    input:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup.bam",
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup.matrix"
    log:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup.log"
    shell:
        "{JAVA} -Xms80g -Xmx80g -XX:ParallelGCThreads=24 -jar {PICARD} MarkDuplicates I={input} O={output[0]} M={output[1]} ASO=coordinate REMOVE_DUPLICATES=true 2>{log}"
        

# 268 = read unmapped + mate unmapped +  not primary alignment
# 3 = read paired properly
# 原本 {SAMTOOLS} view -hb -f 3 -F 268 -q 20 -@ 24 -O BAM -o {output} {input}
rule A14_BAM_Q20_quality_FiltClip:
    input:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup.bam"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam"
    shell:
        """
        {SAMTOOLS} view -h -f 3 -F 268 -q 20 {input} | {SAMCLIP} --ref {BWA_HG38_IDX} --max 3 --progress 0 | awk 'function abs(v) {{return v < 0 ? -v : v}} $1~"@" || ($7 == "=" && abs($9) <= 2500 ) {{print $0}}' | {SAMTOOLS} view -hb > {output}
        """


rule A15_rmdup_Q20_bam_index:
    input:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam.bai"
    shell:
        "{SAMTOOLS} index -@ 24 {input} {output}"


rule A16_BAM_stats:                                      
    input:
        bam = "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam",
        bam_index = "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam.bai"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam.mapping_stats"
    shell:
        "{SAMTOOLS} stats -@ 24 --reference {BWA_HG38_IDX} {input.bam} > {output}"


rule A17_Rm_rRNA_FastQC:
    input:
        "../3.Process/01.fix_fastq/{sample}_rm_rRNA.fq.1.gz",
        "../3.Process/01.fix_fastq/{sample}_rm_rRNA.fq.2.gz"
    output:
        directory("../3.Process/00.MultiQC/03.Rm_rRNA_MultiQC/FastQC/{sample}")
    log:
        "../3.Process/00.MultiQC/03.Rm_rRNA_MultiQC/FastQC/{sample}/{sample}.rm_rRNA.fastqc.log"
    shell:
        """
        mkdir -p {output} && \
        {FASTQC} -o {output} -t 24 {input[0]} {input[1]} > {log} 2>&1
        """


rule A18_Rm_rRNA_MultiQC:
    input: 
        expand("../3.Process/00.MultiQC/03.Rm_rRNA_MultiQC/FastQC/{sample}",sample=SAMPLES)
    output:
        directory("../3.Process/00.MultiQC/03.Rm_rRNA_MultiQC/MultiQC")
    log:
        "../3.Process/00.MultiQC/03.Rm_rRNA_MultiQC/MultiQC/Rm_rRNA_multiqc_report.html.log"
    shell: 
        """
        mkdir -p {output} && \
        {MULTIQC} {input} -o {output} -n Rm_rRNA_multiqc_report.html --no-data-dir > {log} 2>&1
        """

        
rule A19_STAR_align_BAM_MultiQC:
    input: 
        expand("../3.Process/02.STAR_bam/{sample}_Log.final.out",sample=SAMPLES)
    output:
        directory("../3.Process/00.MultiQC/04.STAR_align_BAM_MultiQC")
    log:
        "../3.Process/00.MultiQC/04.STAR_align_BAM_MultiQC/STAR_align_BAM_multiqc_report.html.log"
    shell: 
        """
        mkdir -p {output} && \
        {MULTIQC} {input} -o {output} -n STAR_align_BAM_multiqc_report.html --no-data-dir > {log} 2>&1
        """

        
rule A20_Sort_BAM_MultiQC:
    input: 
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort.bam.mapping_stats",sample=SAMPLES)
    output:
        directory("../3.Process/00.MultiQC/05.Sort_BAM_MultiQC")
    log:
        "../3.Process/00.MultiQC/05.Sort_BAM_MultiQC/Sort_BAM_multiqc_report.html.log"
    shell: 
        """
        mkdir -p {output} && \
        {MULTIQC} {input} -o {output} -n Sort_BAM_multiqc_report.html --no-data-dir > {log} 2>&1
        """

        
rule A21_Rmdup_MultiQC:
    input: 
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup.matrix",sample=SAMPLES)
    output:
        directory("../3.Process/00.MultiQC/06.Rmdup_MultiQC")
    log:
        "../3.Process/00.MultiQC/06.Rmdup_MultiQC/Rmdup_multiqc_report.html.log"
    shell: 
        """
        mkdir -p {output} && \
        {MULTIQC} {input} -o {output} -n Rmdup_multiqc_report.html --no-data-dir > {log} 2>&1
        """
        
# # "../3.Process/00.MultiQC/07.Final_BAM_MultiQC/Final_BAM_multiqc_report_data/multiqc_general_stats.txt"
rule A22_Final_BAM_MultiQC:
    input: 
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam.mapping_stats",sample=SAMPLES)
    output:
        path = directory("../3.Process/00.MultiQC/07.Final_BAM_MultiQC"),
        stats = "../3.Process/00.MultiQC/07.Final_BAM_MultiQC/multiqc_general_stats.txt"
    log:
        "../3.Process/00.MultiQC/07.Final_BAM_MultiQC/Final_BAM_multiqc_report.html.log"
    shell: 
        """
        mkdir -p {output.path} && \
        {MULTIQC} {input} -o {output.path} -n Final_BAM_multiqc_report.html > {log} 2>&1 && \
        cp ../3.Process/00.MultiQC/07.Final_BAM_MultiQC/Final_BAM_multiqc_report_data/multiqc_general_stats.txt {output.stats}
        """

# ### Here has another process: all bam downsampling for subsequent analyses ###
# ### 在shell中，awk内的变量都要双大括号，并且linux内比较不能用大于号或小于号，要用-eq, -ge等
# ### rules.A22_Final_BAM_MultiQC.output.stats表示等A22 rule的output stats生成以后才开始runA23
rule A23_Downsampling:
    input:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam",
        "../3.Process/00.MultiQC/07.Final_BAM_MultiQC/multiqc_general_stats.txt",
        rules.A22_Final_BAM_MultiQC.output.stats
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam"
    params:
        down_to_size = lambda wildcards, input: Get_Downsample_Scale(input[1])
        # down_to_size = 84000000
    shell:
        """ 
        frac=$( {SAMTOOLS} idxstats {input[0]} | cut -f3 | awk 'BEGIN {{total=0}} {{total += $1}} END {{frac={params.down_to_size}/total; if (frac >= 1) {{print 1}} else {{print frac}} }}' ); echo $frac; if [ $frac -ge 1 ]; then cp {input[0]} {output}; else {SAMTOOLS} view -bs $frac {input[0]} > {output}; fi
        """
        
rule A24_Downsampling_bam_index:
    input:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam.bai"
    shell:
        "{SAMTOOLS} index -@ 24 {input} {output}"
        
        
rule A25_Downsampling_BAM_stats:                                      
    input:
        bam = "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam",
        bam_index = "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam.bai"
    output:
        "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam.mapping_stats"
    shell:
        "{SAMTOOLS} stats -@ 24 --reference {BWA_HG38_IDX} {input.bam} > {output}"
        

rule A26_Downsampling_BAM_MultiQC:
    input: 
        expand("../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam.mapping_stats",sample=SAMPLES)
    output:
        directory("../3.Process/00.MultiQC/08.Downsample_BAM_MultiQC")
    log:
        "../3.Process/00.MultiQC/08.Downsample_BAM_MultiQC/Downsample_BAM_multiqc_report.html.log"
    shell: 
        """
        mkdir -p {output} && \
        {MULTIQC} {input} -o {output} -n Downsample_BAM_multiqc_report.html --no-data-dir > {log} 2>&1
        """
           
# ### if known some region add -l region.bed, else rm -l param ###
# # High_Express_Gene = "../3.Process/03.Quantify/Filt_readcount_cover15_979genes.bed"
# # -l produce mpileup within a region (4 column BED)

rule A27_bam_to_mpileup:
    input:
        bam = "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam",
        bam_index = "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam.bai"
    output:
        "../3.Process/03.mpileup/{sample}_Aligned_sort_MarkDup_rmdup.mpileup"
    log:
        "../3.Process/03.mpileup/{sample}_Aligned_sort_MarkDup_rmdup.mpileup.log"
    shell:
        "{SAMTOOLS} mpileup --reference {BWA_HG38_IDX} \
        -q 20 -Q 20 -o {output} {input.bam} > {log} 2>&1"
        

rule A28_mpileup_to_bmat:
    input:
        "../3.Process/03.mpileup/{sample}_Aligned_sort_MarkDup_rmdup.mpileup"
    output:
        "../3.Process/04.bmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20.bmat"
    log:
        "../3.Process/04.bmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20.bmat.log"
    params:
        "../2.Codes/parse-mpileup-V04.py"
    shell:
        "{PYTHON} {params} -i {input} -o {output} -p 24 -n 0 > {log} 2>&1"
        

rule A29_bmat_to_pmat:
    input:
        "../3.Process/04.bmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20.bmat"
    output:
        "../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20.pmat"
    log:
        "../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20.pmat.log"
    params:
        pmat = "../2.Codes/bmat2pmat-V02.py"
    shell:
        """
        {PYTHON} {params.pmat} -i {input} -o {output} --InHeader True --InLikeBED False --OutHeader False > {log} 2>&1
        """
        

rule A30_pmat_rmSNP:
    input:
        "../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20.pmat"
    output:
        "../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20_rmSNP.pmat"
    shell:
        """
        {BEDTOOLS} intersect -sorted -a {input} -b {SNP_VCF} -wa -v > {output}
        """
        
### awk '$11 != "." {{print $0}}' {input} > {output}
### awk '$11 != "." && $14 >=3 {{print $0}}' {input} > {output}, 后面A35写了程序筛low cover的点
rule A31_Get_mut_sites:
    input:
        "../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20_rmSNP.pmat"
    output:
        "../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20_rmSNP_mut.pmat"
    shell:
        """
        awk '$11 != "." {{print $0}}' {input} > {output}
        """ 
        
rule A32_pmat_add_Pvalue_Qvalue:
    input:
        "../3.Process/05.pmat/{sample}_Aligned_sort_MarkDup_rmdup_MAPQ20_rmSNP_mut.pmat"
    output:
        "../3.Process/05.pmat/{sample}_SMART_rmSNP_mut_Add_Pval_Qval.pmat"
    shell:
        """
        {RSCRIPT} ../2.Codes/Add_Pval_Qval.R {input} {output}
        """
    
    
rule A33_Fix_Case:
    input:
        expand("../3.Process/05.pmat/{sample}_SMART_rmSNP_mut_Add_Pval_Qval.pmat",sample=SAMPLES)
    output:
        "../3.Process/06.filt_pmat/{sample}_SMART_rmSNP_mut_fix_cases.pmat"
    params:
        # cases = lambda wildcards, output: Get_case_ls(output[0].split("/")[-1].split("_SMART")[0]),
        cases = lambda wildcards, output: Get_samples_str("../3.Process/05.pmat", "_SMART_rmSNP_mut_Add_Pval_Qval.pmat", Samples_crrelation[output[0].split("_SMART")[0].split("/")[-1]]),
        case_file = lambda wildcards, output: Get_sample_name("../3.Process/05.pmat", output[0].split("/")[-1].split("_SMART")[0], "_SMART_rmSNP_mut_Add_Pval_Qval.pmat")
    shell:
        """
        {BEDTOOLS} intersect -sorted -a {params.case_file} -b {params.cases} -wa -v > {output}
        """        

rule A34_Cases_jitter_mutheat:
    input:
        expand("../3.Process/06.filt_pmat/{sample}_SMART_rmSNP_mut_fix_cases.pmat",sample=SAMPLES)
    output:
        jitter = "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot.pdf",
        mutheat = "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Mutheatplot.pdf"
    params:
        pmat_path = "../3.Process/06.filt_pmat",
        mut_combine = MUT_COMBINE,
        mut_num = "{mut_count}",
        cover_num = "{cover_count}",
        mut_ratio = "{mut_ratio}",
        max_cover = "Unlimited",
        qvalue_cut = "{qvalue_cutoff}",
        split_pattern = "_SMART",
        outpath = "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}",
        samples_level = SAMPLES_LEVEL,
        samples_color = SAMPLES_COLOR,
        jitter_height = 50,
        jitter_width = 60,
        mutheat_height = 30,
        mutheat_width = 30,
        mut_heat_color = "Purples",
        mut_heat_value = "0,6,7,8,9,10,11,12,13,15",
        mut_heat_lebel = "0,10,100,1000,10000",
        ylim_max = 110,
        label_pos = 103,
        xintercept = "2.5,8.5"
    shell:
        """
        {RSCRIPT} ../2.Codes/pmat_filt_jitter_heat_v7.R {params.pmat_path} .pmat {params.mut_combine} \
            {params.mut_num} {params.cover_num} {params.mut_ratio} {params.max_cover} {params.qvalue_cut} \
            {params.split_pattern} {params.outpath} {params.samples_level} {params.samples_color} \
            {output.jitter} {params.jitter_height} {params.jitter_width} \
            {output.mutheat} {params.mutheat_height} {params.mutheat_width} \
            {params.mut_heat_color} {params.mut_heat_value} {params.mut_heat_lebel} \
            {params.ylim_max} {params.label_pos} {params.xintercept} raw
        """
        
        
rule A35_Rm_low_cover_site_muts:
    input:
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot.pdf",
               mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF)
    output:
        "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt"
    params:
        input_file = lambda wildcards, output: output[0].split("_rm")[0]+"_filter.txt",
        path = "../3.Process/02.STAR_bam",
        sample = ",".join(CTRL_SAMPLES_1),
        cover = 3
    shell:
        """
        {PYTHON3} ../2.Codes/Rm_empty_cover_sites.py -path {params.path} \
            -s {params.sample} -c {params.cover} -pmat {params.input_file} -o {output}
        """


rule A36_Rm_low_cover_site_custom_plot_jitter:
    input:
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
               mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES,mut_ls=MUT_COMBINE_f)
    output:
        "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_low_cover_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot_{mut_ls}.pdf"
    params:
        path = "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}",
        file_pattern = "{mut_ls}_rm_low_cover.txt",
        sample_pattern = "_M{mut_count}C{cover_count}R{mut_ratio}",
        mut_count_cutoff = "{mut_count}",
        cover_count_cutoff = "{cover_count}",
        mut_ratio_cutoff = "{mut_ratio}",
        fwd_mut = lambda wildcards, output: output[0].split("Jitterplot_")[1].split(".pdf")[0].split("_")[0],
        rev_mut = lambda wildcards, output: output[0].split("Jitterplot_")[1].split(".pdf")[0].split("_")[1],
        samples = SAMPLES_LEVEL,
        colors = SAMPLES_COLOR,
        xintercept = "2.5,8.5",
        pdf_height = 12,
        pdf_width = 16,
        pmat_type = "pvalue_pmat"
    shell:
        """
        {RSCRIPT} ../2.Codes/Jitter_custom_plot.R {params.path} {params.file_pattern} {params.sample_pattern} \
            {params.mut_count_cutoff} {params.cover_count_cutoff} {params.mut_ratio_cutoff} {params.fwd_mut} \
            {params.rev_mut} {params.samples} {params.colors} {params.xintercept} {output} \
            {params.pdf_height} {params.pdf_width} {params.pmat_type}
        """
        
        
        
### ============================= ###
### Motif and Annotation analyses ###
### ============================= ###
# _rm_low_cover
rule A37_Get_RNA_status:
    input:
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_low_cover_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot_{mut_ls}.pdf",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES,mut_ls=MUT_COMBINE_f)
    output:
        "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_Extend_l{left_extend}r{right_extend}_RNA.txt",
        "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_filter.txt"
    params:
        status = "../2.Codes/Get_RNA_status.py",
        filters = "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}",
        key_str = "{mut_type}",
        left_extend = "{left_extend}",
        right_extend = "{right_extend}",
        min_mut = lambda wildcards, output: int(output[0].split("/")[-3].split("_")[1].split("-")[0]),
        max_mut = lambda wildcards, output: int(output[0].split("/")[-3].split("_")[1].split("-")[1]),
        fwd_mut = lambda wildcards, output: output[0].split("/")[-2].split("_rm")[0].split("_")[0],
        rev_mut = lambda wildcards, output: output[0].split("/")[-2].split("_rm")[0].split("_")[1],
        outpath = "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}"
    shell:
        """
        {PYTHON3} {params.status} -ref {BWA_HG38_IDX} -f {params.filters} -k {params.key_str} \
            --left_extend {params.left_extend} --right_extend {params.right_extend} \
            --min_mut_ratio {params.min_mut} --max_mut_ratio {params.max_mut} \
            --fwd_mut_type {params.fwd_mut} --rev_mut_type {params.rev_mut} --output_files_path {params.outpath}
        """

rule A38_Motif_plots:
    input:
        expand("../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_Extend_l{left_extend}r{right_extend}_RNA.txt",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR)
    output:
        extend_pdf = "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/Extend_sites_motifs.pdf",
        codon_pdf = "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/Codon_sites_motif.pdf"
    params:
        motif = "../2.Codes/Plot_motif_server.R",
        seqs_path = "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}",
        # plot_cols = int(len(SAMPLES)**0.5),
        plot_cols = 1,
        extend_pdf_height = 24,
        extend_pdf_width = 14,
        codon_pdf_height = 15,
        codon_pdf_width = 18
    shell:
        """
        {RSCRIPT} {params.motif} {params.seqs_path} {params.plot_cols} \
            {output.extend_pdf} {params.extend_pdf_height} {params.extend_pdf_width} \
            {output.codon_pdf} {params.codon_pdf_height} {params.codon_pdf_width}
        """

rule A39_Multiple_barplots:
    input:
        expand("../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/Extend_sites_motifs.pdf",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR)
    output:
        barplot = "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/Multiple_RNA_status.pdf"
    params:
        barplot = "../2.Codes/Multiple_histogram_par_server.R",
        seqs_path = "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}",
        plot_cols = int(len(SAMPLES)**0.5),
        plot_height = 12,
        plot_width = 20
    priority: 10
    shell:
        """
        {RSCRIPT} {params.barplot} {params.seqs_path} {output.barplot} \
            {params.plot_cols} {params.plot_height} {params.plot_width}
        """

        
### ============================= ###
###      Annotation analyses      ###
### ============================= ###

### Remenber install hg38 related data use path_to/miniconda/share/homer/configureHomer.pl install
### annotatePeak.pl is path_to/miniconda/bin/annotatePeak.pl
rule A40_Homer_annotation:
    input:
        "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_filter.txt"
    output:
        anno = "../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_anno.txt",
        stats = "../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_anno.stats"
    log:
        "../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_anno.log"
    shell:
        """
        {ANNOTATE_PEAK} {input} hg38 -annStats {output.stats} > {output.anno} 2>{log}
        """

rule A41_Filt_stats:
    input:
        "../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_anno.stats"
    output:
        "../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_anno_filt.stats"
    shell:
        """
        head -n 14 {input} > {output}
        """
        
rule A42_Anno_Stack_barplot:
    input:
        expand("../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_anno_filt.stats",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR)
    output:
        out_pdf = "../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/R_{ratio_region}_stack_barplot.pdf"
    params:
        stack = "../2.Codes/Plot_Homer_stacked_barplots_server.R",
        case_levels = SAMPLES_LEVEL,
        colors_values = STACK_BARPLOT_COLORS_STR_HOMER,
        stats_path = "../3.Process/08.bmat_pipe/02.Annotation/Homer/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}",
        in_pattern = "filt.stats",
        xlabel = "",
        ylabel = "Percentage"
    shell:
        """
        {RSCRIPT} {params.stack} {params.case_levels} \
            {params.colors_values} {params.stats_path} \
            {params.in_pattern} {output} 9 12 {params.xlabel} {params.ylabel}
        """

rule A43_Samtools_extract_bam:
    input:
        bam = "../3.Process/02.STAR_bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam",
        bed = "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_R_{ratio_region}_filter.txt"
    output:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_region_R_{ratio_region}.bam"
    params:
        path = "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}"
    shell:
        """
        {SAMTOOLS} view -Sbh -L {input.bed} {input.bam} > {output}
        """

rule A44_BAM_sort:
    input:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_region_R_{ratio_region}.bam"
    output:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_region_R_{ratio_region}_sort.bam"
    shell:
        """
        {SAMTOOLS} sort -O BAM -o {output} -T {output}.temp {input}
        """
        ### {SAMTOOLS} sort -O BAM -o {output} -T {output}.temp -@ 4 -m 4G {input}

rule A45_Extract_BAM_idx:
    input:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_region_R_{ratio_region}_sort.bam"
    output:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_region_R_{ratio_region}_sort.bam.bai"
    shell:
        """
        {SAMTOOLS} index {input} {output}
        """

rule A46_RSeQC_annotation:
    input:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_region_R_{ratio_region}_sort.bam"
    output:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_RSeQC_anno.txt"
    log:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_RSeQC_anno.log"
    shell:
        """
        {PYTHON} {READ_DISTRIBUTION} -i {input} -r {HG38_REFSEQ_BED} > {output} 2>{log}
        """

### mac: sed -i '' "s/'/_/" {output}
### linux: sed -i "s/'/_/" {output}
rule A47_Filt_RSeQC_anno:
    input:
        expand("../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_RSeQC_anno.txt",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR),
        anno = "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_RSeQC_anno.txt"
    output:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_RSeQC_anno_filt.txt"
    shell:
        """
        tail -n 12 {input.anno} | head -n 11 | awk 'BEGIN{{ FS=" ";OFS="\t" }} {{print $1,$2,$3,$4}}' - > {output} && \
        sed -i "s/'/_/" {output}
        """


rule A48_RSeQC_stacked_barplot:
    input:
        expand("../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/{sample}_RSeQC_anno_filt.txt",
            mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,ratio_region=RATIO_REGION,sample=SAMPLES,left_extend=LEFT_EXTEND,right_extend=RIGHT_EXTEND,mut_type=KEY_STR)
    output:
        "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}/RSeQC_R_{ratio_region}_stackbar.pdf"
    params:
        RSeQC_bar = "../2.Codes/Plot_universal_stacked_barplots_server.R",
        case_levels = SAMPLES_LEVEL,
        Colors_values = STACK_BARPLOT_COLORS_STR_RSEQC,
        stats_path = "../3.Process/08.bmat_pipe/02.Annotation/RSeQC/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_type}",
        in_pattern = "filt.txt",
        ylabel = "Percentage",
        input_cols = "Group,Total_bases,Tag_count,Tags_Kb",
        plot_y = "Tag_count",
        fill_bar = "Group",
        anno_level = "CDS_Exons,5_UTR_Exons,3_UTR_Exons,Introns,TSS_up_1kb,TES_down_1kb"
    shell:
        """
        {RSCRIPT} {params.RSeQC_bar} \
            {params.case_levels} {params.Colors_values} {params.stats_path} \
            {params.in_pattern} {output} 9 12 {params.ylabel} {params.input_cols} \
            {params.plot_y} {params.fill_bar} {params.anno_level}
        """
        
        
        
rule A49_Sites_overlap_venn_plot:
    input:
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{treat_sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,mut_ls=MUT_COMBINE_f,treat_sample=SAMPLES),
        sam1 = "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{treat_sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
        sam2 = "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{ctrl_sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt"
    output:
        "../3.Process/10.Venn_plots/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{treat_sample}_vs_{ctrl_sample}_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}_{mut_ls}_venn.pdf"
    shell:
        """
        {RSCRIPT} ../2.Codes/Plot_venn_server.R {input.sam1} {input.sam2} _M3C15R0 {output} 10 10
        """
        

rule A50_Sites_overlap_specific_motif:
    input:
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample1}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample1=SAMPLES,mut_ls=MUT_COMBINE_f),
        s1_pmat = "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample1}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
        s1_motif = "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_ls}_rm_low_cover/{sample1}_Extend_l{left_extend}r{right_extend}_RNA.txt",
        s2_pmat = "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample2}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
        s2_motif = "../3.Process/08.bmat_pipe/01.RNA_status/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_ls}_rm_low_cover/{sample2}_Extend_l{left_extend}r{right_extend}_RNA.txt"
    output:
        "../3.Process/11.Motif_sprcific/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_ls}_rm_low_cover/{sample1}_vs_{sample2}/{sample1}_vs_{sample2}_{mut_ls}_overlap_and_specific_motif.pdf"
    params:
        s1_name = "{sample1}",
        s2_name = "{sample2}",
        pdf_height = 12,
        pdf_width = 10,
        path = "../3.Process/11.Motif_sprcific/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/Extend_l{left_extend}r{right_extend}/R_{ratio_region}/{mut_ls}_rm_low_cover/{sample1}_vs_{sample2}",
        motif_method = "bits"
    shell:
        """
        {RSCRIPT} ../2.Codes/crRNA_specific.R {params.s1_name} {input.s1_pmat} {input.s1_motif} \
            {params.s2_name} {input.s2_pmat} {input.s2_motif} {output} {params.pdf_width} {params.pdf_height} {params.path} {params.motif_method}
        """

## Other mutation heatmap plot ###
rule A51_Rm_low_cover_other_mut_sites:
    input:
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot.pdf",
               mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF)
    output:
        "../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_other_mut_rm_low.txt"
    params:
        input_file = lambda wildcards, output: output[0].split("_other")[0]+"_filter_other_mut.txt",
        path = "../3.Process/02.STAR_bam",
        sample = ",".join(CTRL_SAMPLES_1),
        cover = 3
    shell:
        """
        {PYTHON3} ../2.Codes/Rm_empty_cover_sites.py -path {params.path} \
            -s {params.sample} -c {params.cover} -pmat {params.input_file} -o {output}
        """
        
rule A52_Cat_all_rm_low_sites:
    input:
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_other_mut_rm_low.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES),
        expand("../3.Process/07.Jitter_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_{mut_ls}_rm_low_cover.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES,mut_ls=MUT_COMBINE_f)
    output:
        "../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_rm_low_cover_merge.txt"
    params:
        fwd = lambda wildcards, output: output[0].split("_rm")[0].replace("12.Other_Mutheat_plot", "07.Jitter_Mutheat_plot")+"_"+FWD+"_rm_low_cover.txt",
        rev = lambda wildcards, output: output[0].split("_rm")[0].replace("12.Other_Mutheat_plot", "07.Jitter_Mutheat_plot")+"_"+REV+"_rm_low_cover.txt",
        other = lambda wildcards, output: output[0].split("_rm")[0].replace("12.Other_Mutheat_plot", "07.Jitter_Mutheat_plot")+"_other_mut_rm_low.txt"
    shell:
        """
        cat {params.other} {params.fwd} {params.rev} > {output}
        """
        
        
rule A53_Rm_low_cover_jitter_mutheat:
    input:
        expand("../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/{sample}_M{mut_count}C{cover_count}R{mut_ratio}_rm_low_cover_merge.txt",
              mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF,sample=SAMPLES)
    output:
        jitter = "../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_rm_low_cover_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot.pdf",
        mutheat = "../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_rm_low_cover_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Mutheatplot.pdf"
    params:
        pmat_path = "../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}",
        mut_combine = MUT_COMBINE,
        mut_num = "{mut_count}",
        cover_num = "{cover_count}",
        mut_ratio = "{mut_ratio}",
        max_cover = "Unlimited",
        qvalue_cut = "{qvalue_cutoff}",
        split_pattern = "_M{mut_count}C{cover_count}R{mut_ratio}",
        outpath = "../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}",
        samples_level = SAMPLES_LEVEL,
        samples_color = SAMPLES_COLOR,
        jitter_height = 50,
        jitter_width = 60,
        mutheat_height = 30,
        mutheat_width = 30,
        mut_heat_color = "Blues",
        mut_heat_value = "0,6,7,8,9,10,11,12,13,15",
        mut_heat_lebel = "0,10,100,1000,10000",
        ylim_max = 110,
        label_pos = 103,
        xintercept = "2.5,8.5"
    shell:
        """
        {RSCRIPT} ../2.Codes/pmat_filt_jitter_heat_v7.R {params.pmat_path} rm_low_cover_merge.txt {params.mut_combine} \
            {params.mut_num} {params.cover_num} {params.mut_ratio} {params.max_cover} {params.qvalue_cut} \
            {params.split_pattern} {params.outpath} {params.samples_level} {params.samples_color} \
            {output.jitter} {params.jitter_height} {params.jitter_width} \
            {output.mutheat} {params.mutheat_height} {params.mutheat_width} \
            {params.mut_heat_color} {params.mut_heat_value} {params.mut_heat_lebel} \
            {params.ylim_max} {params.label_pos} {params.xintercept} add
        """
        
        
rule A54_Cuffdiff_gene_no_rep:
    input:
        expand("../3.Process/12.Other_Mutheat_plot/M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}/SMART_rm_ctrl_rm_low_cover_M{mut_count}C{cover_count}R{mut_ratio}Q{qvalue_cutoff}.Jitterplot.pdf",
               mut_count=MUT_COUNT,cover_count=COVER_COUNT,mut_ratio=MUT_RATIO,qvalue_cutoff=QVALUE_CUTOFF),
        treat = "../3.Process/02.STAR_bam/{deg_treat_sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam",
        ctrl = "../3.Process/02.STAR_bam/{deg_ctrl_sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam"
    output:
        "../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}/{deg_treat_sample}_vs_{deg_ctrl_sample}_cuffdiff.log"
    params:
        op = "../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}",
        treat = "{deg_treat_sample}",
        ctrl = "{deg_ctrl_sample}"
    shell:
        "{CUFFDIFF} -p 24 -o {params.op} -L {params.ctrl},{params.treat} {HG38_GTF} {input.ctrl} {input.treat} > {output} 2>&1"
        
# rule Reads_length_stat:
#     input:
#         "01.Bam/{sample}_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam"
#     output:
#         "01.Bam/{sample}_reads_avg_len.txt"
#     shell:
#         """
#         {SAMTOOLS} view -@ 24 {input} | awk '{sum+=length($10)}END{print "Average = ", sum/NR}' > {output}
#         """

rule A55_Plot_cuffdiff_volcano:
    input:
        expand("../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}/{deg_treat_sample}_vs_{deg_ctrl_sample}_cuffdiff.log",deg_treat_sample=TREAT_SAMPLES_1,deg_ctrl_sample=CTRL_SAMPLES_1)
    output:
        "../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}/Cuffdiff_plot_volcano.log"
    params:
        path = "../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}"
    shell:
        """
        {RSCRIPT} ../2.Codes/Plot_volcano_server.R {params.path} gene_exp.diff 1 0.05 > {output} 2>&1
        """
        
rule A56_Plot_cuffdiff_scatter:
    input:
        expand("../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}/{deg_treat_sample}_vs_{deg_ctrl_sample}_cuffdiff.log",deg_treat_sample=TREAT_SAMPLES_1,deg_ctrl_sample=CTRL_SAMPLES_1)
    output:
        "../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}/Cuffdiff_{deg_treat_sample}_vs_{deg_ctrl_sample}_scatter.pdf"
    params:
        path = "../3.Process/09.Cuffdiff_gene/{deg_treat_sample}_vs_{deg_ctrl_sample}"
    shell:
        """
        {RSCRIPT} ../2.Codes/Plot_cuffdiff_scatter.R {params.path} gene_exp.diff {output} 8 7
        """