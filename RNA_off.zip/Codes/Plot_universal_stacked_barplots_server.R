library(ggplot2)
library(tidyverse)
library(data.table)
library(optparse)

### Set params ###
# option_list = list(
#   make_option(c("-s", "--case_levels"), type="character",help="Input the cases levels"),    
#   make_option(c("-c", "--color_values"), type="character",help="Input the color values, need 13 colors"),
#   make_option(c("-p", "--stats_path"),type="character",help = "Input the stats files path or other want to plot files path"),
#   make_option(c("-t", "--stats_pattern"),type = "character",help = "The input files suffix"),
#   make_option(c("-o","--output_pdf"),type = "character",help = "The output pdf file name"),
#   make_option(c("-h","--plot_height"),type = "integer",help = "The output pdf height"),
#   make_option(c("-w","--plot_width"),type = "integer",help = "The output pdf width"),
#   make_option(c('-x',"--xlabel"),type = "character",help = "The xlabel for show",default = ""),
#   make_option(c("-y","--ylabel"),type = "character",help = "The ylabel for show")
#   )
# opt_parser = OptionParser(option_list=option_list)
# opt = parse_args(opt_parser)

### Main function ###
Plot_stacked_barplots <- function(In_stats_path,In_pattern_str,
                                  Case_levels,Colors_values,
                                  out_pdf_name,plot_height,plot_width,
                                  ylabel, in_cols,
                                  plot_y, fill_obj,anno_levels){
  # cols <- c("Annotation","Number_of_peaks","Total_size_bp","Log2_Ratio","LogP_enrichment")
  cols <- in_cols
  
  Merge_ls <- list()
  filenames <- list.files(In_stats_path, pattern=str_c("*",In_pattern_str), full.names=TRUE)
  for (i in 1:length(filenames)){
    file <- filenames[[i]]
    file_str <- str_split(file,"/")[[1]]
    case <- str_split(file_str[length(file_str)],"_RSeQC")[[1]][1]
    
    df <- read.csv(file,sep = "\t")
    colnames(df) <- cols
    
    df <- mutate(df, Case = case)
    df.f <- df %>% filter(Group != "TSS_up_5kb" & Group != "TSS_up_10kb" & Group != "TES_down_5kb" & Group != "TES_down_10kb")
    # df <- mutate(df, across(everything(), as.factor))
    
    # print(case)
    # print(nrow(df))
    
    Merge_ls[[i]] <- df.f
  }
  
  Strip_df <- bind_rows(Merge_ls) 
  # colnames(Strip_df)
  
  Strip_df$Case <- factor(Strip_df$Case,levels = Case_levels)
  Strip_df$Group <- factor(Strip_df$Group, levels=anno_levels)
  color_value = Colors_values
  
  Strip_df[[plot_y]] <- as.numeric(Strip_df[[plot_y]])
  
  # Strip_df_f <- subset(Strip_df, Case == c("LELmax-P10b","LELvector"))
  # print(Strip_df)
  
  plot <- ggplot(Strip_df, aes(fill=Strip_df[[fill_obj]], y=Strip_df[[plot_y]], x=Case)) + 
    geom_bar(position="fill", stat="identity") +
    scale_fill_manual(values = color_value) +
    theme(panel.background = element_rect(fill = "white", colour = "black", size = 1))+
    theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1, size = 12))+
    xlab("")+
    ylab(ylabel)
  
  ggsave(plot, filename = out_pdf_name, height = plot_height, width = plot_width)
}


### Transfer params ###
args <- commandArgs(trailingOnly = TRUE)

Case_levels <- as.character(unlist(str_split(args[1],",")))
Colors_values <- as.character(str_c("#",unlist(str_split(args[2],","))))
stats_path <- as.character(args[3])
in_pattern <- as.character(args[4])
out_pdf_name <- as.character(args[5])
plot_height <- as.integer(args[6])
plot_width <- as.integer(args[7])
# xlabel <- as.character(args[8])
ylabel <- as.character(args[8])
input_cols <- as.character(unlist(str_split(args[9],",")))
# plot_x_label <- as.character(args[11])
plot_y_label <- as.character(args[10])
fill_bar_label <- as.character(args[11])
annotate_level <- as.character(unlist(str_split(args[12],",")))

Plot_stacked_barplots(In_stats_path = stats_path,In_pattern_str = in_pattern,
                      Case_levels = Case_levels,Colors_values = Colors_values,out_pdf_name = out_pdf_name,
                      plot_height = plot_height, plot_width = plot_width, 
                      ylabel = ylabel, in_cols = input_cols,
                      plot_y = plot_y_label, fill_obj = fill_bar_label,anno_levels=annotate_level)

# t <- read.csv("04.Homer_annotation/M5C10R0_AG_TC/R_50-100/E8e-NT_R_50-100_anno_filt.stats",sep = "\t")
# cols <- c("Annotation","Number_of_peaks","Total_size_bp","Log2_Ratio","LogP_enrichment")
# df <- t[1:match("Annotation",t$Annotation)-1,]
# if ("Annotation" %in% t$Annotation){
#   print("yes")
# }else{
#   print("no")
# }

# library(tidyverse)
# t <- read.csv("04.Annotation/RSeQC/M5C10R0_AG_TC/R_0-100/E8e-NT_RSeQC_anno_filt.txt",sep = "\t")
# t <- t %>% mutate(case = "E8e-NT")
# colnames(t)
# table(t$Group)
# t$Group <- factor(t$Group,levels = c("CDS_Exons","5'UTR_Exons","3'UTR_Exons","Introns",
#                                      "TSS_up_10kb","TSS_up_5kb","TSS_up_1kb",
#                                      "TES_down_10kb","TES_down_5kb","TES_down_1kb"))
# plot <- ggplot(t, aes(fill=t[["Group"]], y=t[["Tag_count"]], x=case)) +
#   geom_bar(position="fill", stat="identity") +
#   # scale_fill_manual(values = color_value) +
#   theme(panel.background = element_rect(fill = "white", colour = "black", size = 1))+
#   theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1, size = 12))+
#   xlab("")+
#   ylab("percentage")
