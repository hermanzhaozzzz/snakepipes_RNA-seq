library(tidyverse)
library(ggplot2)
library(gridExtra)

args <- commandArgs(trailingOnly = TRUE)

Multiplot_barplot <- function(in_seqs_path, file_patter,
                              out_pdf_name, plot_ncol,
                              plot_height, plot_width){
  file_path <- in_seqs_path
  Path_seqs <- list.files(file_path,pattern = file_patter)
  plot_merge <- list()
  for (i in 1:length(Path_seqs)){
    case <- str_split(Path_seqs[[i]],"_codon_status")[[1]][1]
    file_path <- str_c(in_seqs_path,"/",Path_seqs[[i]])
    
    ts <- read.table(file_path,sep = "\t",header = T)
    
    p <- ggplot(ts,aes(x=Codon_type,y=Count))+
      geom_bar(stat = "identity",fill="#0077b6")+theme_bw()+theme_classic()+
      theme(axis.text.x = element_text(angle = 45, vjust = 0.6, hjust = 0.5,size = 12))+
      xlab("edit site motif") +
      ylab("number of motifs")+
      ggtitle(str_c(case," (",sum(ts$Count),")"))
      # ggtitle(str_c("motif off-targets for ",case," targeting"," (",sum(ts$Count),")"))
    
    plot_merge[[i]] <- p
  }
  
  
  grid.arrange(grobs = plot_merge, ncol = plot_ncol) ## display plot
  ggsave(file = out_pdf_name, 
         arrangeGrob(grobs = plot_merge, ncol = plot_ncol), height = plot_height, width = plot_width)  ## save plot
}



input_seqs_path <- args[1]
# if (substring(input_seqs_path_t,nchar(input_seqs_path_t)) == "/"){
#   input_seqs_path <- substring(input_seqs_path_t,1,nchar(input_seqs_path_t)-1)
# }else{
#   input_seqs_path <- input_seqs_path_t
# }
out_pdf_name_barplot <- args[2]
plot_cols <- as.integer(args[3])
plot_height <- as.integer(args[4])
plot_width <- as.integer(args[5])

Multiplot_barplot(in_seqs_path = input_seqs_path, file_patter = "*codon_status",
                  out_pdf_name = out_pdf_name_barplot, plot_ncol = plot_cols, 
                  plot_height = plot_height, plot_width = plot_width)

