library(ggplot2)
library(tidyverse)

args <- commandArgs(trailingOnly = TRUE)
cover_file <- args[1]
out_file <- args[2]

file <- cover_file

df <- read.csv(file,header = F)

case <- str_split(string = file,pattern = "_out")[[1]][1]

df["cover_cut"] <- c(1:30)
colnames(df) <- c("count","cover_cut")

df$cover_cut <- factor(df$cover_cut, levels = df$cover_cut)

Mystyle <- theme(
  axis.text.x = element_text(angle = 0, colour = "black", hjust = 0.5, vjust = 1, size = 10), ## 0.5是居中
  axis.text.y = element_text(colour = "black", hjust = 0.5, vjust = 0.5, size = 10),
  axis.title.x = element_text(colour = "black", hjust = 0.5, vjust = 0.5, size = 12),
  axis.title.y = element_text(colour = "black", hjust = 0.5, vjust = 0.5, size = 12),
  axis.ticks.length.x = unit(2,"mm"),axis.ticks.length.y = unit(2,"mm"),
  # axis.ticks.x = element_line(linewidth = 0.5, colour = "black"),
  # axis.ticks.y = element_line(linewidth = 0.5, colour = "black"),
  # axis.line.x = element_line(linewidth = 0.5, colour = "black"),
  # axis.line.y = element_line(linewidth = 0.5, colour = "black")
)

p <- ggplot(df, aes(cover_cut,count*100/(3*10^9)))+
  geom_point(size=2,color="#023e8a")+geom_path(aes(group = 1))+
  theme_bw()+theme_classic()+
  # geom_vline(xintercept = 10, linetype = "dashed", color = "grey")+
  geom_hline(yintercept = 3, linetype = "dashed", color = "grey")+
  Mystyle+
  ylab("Percantage (%) of whole genome")+
  xlab("Cover cutoff for base")+
  ggtitle(case)

p

ggsave(p, file=out_file, height = 4, width = 6)




