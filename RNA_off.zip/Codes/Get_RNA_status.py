#!/usr/bin/env python
import argparse
import re
import os
import pysam
from Bio.Seq import Seq

#!!! parser的help描述中不能有 % ！！！

# ============= main part ==========>>>>>>>>>>>>>>>>>>>>>>
if __name__ == '__main__':
	parser = argparse.ArgumentParser(description="From Filt pmat files get codon RNA sequence, extend RNA sequence and off-target site RNA motif status")
	parser.add_argument("-ref","--reference", help="Input the reference fasta sequence",required=True)
	parser.add_argument("-f","--input_filt_files", help="Input the filtered files path",required=True)
	parser.add_argument('-k',"--file_key_str",help="The key str in file names for filt",required=True)
	parser.add_argument("--left_extend",help="Left extend length, default=2",required=False,default=2)
	parser.add_argument("--right_extend",help="Right extend length, default=4",required=False,default=4)
	parser.add_argument("--min_mut_ratio",help="Minimum mutation ratio,default=0",required=False,default=0)
	parser.add_argument("--max_mut_ratio",help="Maximum mutation ratio,default=100",required=False,default=100)
	parser.add_argument("--fwd_mut_type",help="Forward mutation type",required=True)
	parser.add_argument("--rev_mut_type",help="Reverse mutation type",required=True)
	parser.add_argument("--output_files_path",help="The output RNA status files path",required=True)

	ARGS = parser.parse_args()

	### ==== identify params and load files =====###
	Ref_seq = ARGS.reference
	Filter_files = ARGS.input_filt_files
	key_str = ARGS.file_key_str
	Left_Extend = int(ARGS.left_extend)
	Right_Extend = int(ARGS.right_extend)
	min_mut_ratio = ARGS.min_mut_ratio
	max_mut_ratio = ARGS.max_mut_ratio
	fwd_mut = ARGS.fwd_mut_type
	rev_mut = ARGS.rev_mut_type
	Output_path = ARGS.output_files_path

	### =======================================>>>>>>
	### ============ Main analysis part ========= ###
	### =======================================>>>>>>
	Ref = Ref_seq
	Ref_proj = pysam.FastaFile(Ref)

	file_path = Filter_files
	Left_extend = Left_Extend
	Right_extend = Right_Extend
	min_ratio = min_mut_ratio
	max_ratio = max_mut_ratio

	if Output_path[-1] == "/":
		Output_path = Output_path
	else:
		Output_path = Output_path + "/"
	# Outpath = Output_path+ "/R_" + str(min_ratio) + "-" + str(max_ratio) + "/"
	Outpath = Output_path
	if not os.path.exists(Outpath):
		os.makedirs(Outpath)

	if file_path[-1] == "/":
		file_path = file_path
	else:
		file_path = file_path + "/"


	fwd = fwd_mut
	rev = rev_mut
	oreintation = {fwd: "+", rev: "-"}

	for subdir, dirs, files in os.walk(file_path):
		for file in files:
			if str(key_str) in file and "checkpoint" not in file:
				case = file.split("_M")[0]
#                 print(case)
				Extend_RNA = open(Outpath + case + "_Extend_l" + str(Left_extend) + "r" + str(Right_extend) + "_RNA.txt", "w")
				Extend_RNA_pos = open(Outpath + case + "_Extend_l" + str(Left_extend) + "r" + str(Right_extend) + "_RNA_pos.txt", "w")
				Codon_RNA = open(Outpath + case + "_codon_RNA.txt", "w")
				Codon_status = open(Outpath + case + "_codon_status.txt", "w")
				Codon_status.write("Codon_type" + "\t" + "Count" + "\n")
				Filter_ratio_files = open(Outpath + case + "_R_"+min_ratio+"-"+max_ratio+"_filter.txt", "w")

				Codons = {}
				with open(file_path + file) as f:
					for lines in f:
						line = lines.strip().split("\t")
						chrom, site, type_m = line[0], line[1], line[11]
						ratio = float(line[-1])

						if float(min_ratio) < ratio <= float(max_ratio):
							if type_m in oreintation.keys():

								if oreintation[type_m] == "+":
									start, end = int(site) - Left_extend, int(site) + Right_extend
									extend_seq_DNA = Ref_proj.fetch(chrom, start - 1, end).upper()
									extend_seq_RNA = extend_seq_DNA.replace("T", "U")
									codon_RNA = extend_seq_RNA[Left_extend - 1: Left_extend - 1 + 3]
								elif oreintation[type_m] == "-":
									start, end = int(site) - Right_extend, int(site) + Left_extend
									extend_seq_DNA = Ref_proj.fetch(chrom, start - 1, end).upper()
									extend_seq_DNA = str(Seq(extend_seq_DNA).reverse_complement())
									extend_seq_RNA = extend_seq_DNA.replace("T", "U")
									codon_RNA = extend_seq_RNA[Left_extend - 1: Left_extend - 1 + 3]

								Extend_RNA.write(extend_seq_RNA + "\n")
								Extend_RNA_pos.write(extend_seq_RNA+"\t"+"_".join([chrom,site])+ "\n")
								Codon_RNA.write(codon_RNA + "\n")
								Filter_ratio_files.write(lines)
								if codon_RNA not in Codons.keys():
									Codons[codon_RNA] = 1
								else:
									Codons[codon_RNA] += 1


				if Codons:
					Extend_RNA.close()
					Extend_RNA_pos.close()
					Codon_RNA.close()
					for i in Codons.keys():
						Codon_status.write(i + "\t" + str(Codons[i]) + "\n")
					Codon_status.close()
				else:
					Extend_RNA.write("N"*(Left_extend+Right_Extend+1))
					Extend_RNA_pos.write("N"*(Left_extend+Right_Extend+1))
					Codon_RNA.write("NNN")
					Codon_status.write("NNN"+"\t"+str(0)+"\n")



