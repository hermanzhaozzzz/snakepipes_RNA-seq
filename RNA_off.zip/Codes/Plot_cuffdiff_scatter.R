# library(vidger)
library(tidyverse)
library(ggplot2)
library(ggExtra)
library(ggpubr)
library(ggrepel)

args <- commandArgs(trailingOnly = TRUE)

file_path <- args[1]
file_pattern <- args[2]
outpdf <- args[3]
out_width <- as.integer(args[4])
out_height <- as.integer(args[5])


filenames <- list.files(file_path,pattern = file_pattern)

for (i in 1:length(filenames)){
  in_file <- filenames[[i]]
  
  title_vs <- unlist(str_split(file_path,"/"))[4]
  treat <- unlist(str_split(title_vs,"_vs_"))[1]
  ctrl <- unlist(str_split(title_vs,"_vs_"))[2]
  show_title <- str_c(ctrl, " vs ", treat)
  # colnames(x)
  
  df <- read.csv(str_c(file_path,"/",in_file),sep = "\t")
  # colnames(df)
  df <- df %>% filter(!is.infinite(log2.fold_change.))
  
  ## vsScatterplot ##
  # known <- vsScatterPlot(
  #   x = 'LEL-TadA_V82T-F84I-Y147R_TAG-repoter', y = 'LELvector', data = df, type = 'cuffdiff',
  #   d.factor = NULL, title = TRUE, grid = TRUE, highlight="ADARB1",data.return=TRUE
  # )
  # 
  # known$data
  # known$plot
  
  
  ## ggplot2 sactter plot ##
  df.f <- df %>%
    mutate(gene_type=if_else(        
      p_value > 0.05,"ns",if_else(          
        abs(log2.fold_change.) < 1,"ns",
        if_else(log2.fold_change. >= 1,"up","down"))))
  # colnames(df.f)
  
  df.f <- df.f %>% mutate(
    color_use = case_when(
      gene_type == "ns" ~ "grey",
      gene_type == "up" ~ "#FF0000",
      gene_type == "down" ~ "#00A08A"
    )
  )
  
  p <- ggplot(df.f,aes(x=log10(value_2+1),y=log10(value_1+1)))+
        geom_point(aes(color=color_use))+
        scale_color_manual(name = "", label = c("Down","Up", "Ns"), values = c("#00A08A","#FF0000","grey"))+
        theme_bw()+
        theme(panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              panel.border = element_rect(colour = "black", fill=NA, size=1))+
        xlab(str_c("log10(FPKM+1) ",treat))+
        ylab(str_c("log10(FPKM+1) ",ctrl))+
        geom_abline(linetype="dashed", size=1, alpha=0.7)+ ### plot the y=x line
        # stat_regline_equation(label.x=0.5, label.y=2.5) + ### add the correlation function position
        stat_cor(aes(label=..rr.label..), label.x=0.3, label.y=3.3)+
        xlim(c(0,3.5)) + ylim(c(0,3.5))+
        ggtitle(show_title)
      # geom_label_repel(
      #   data = filter(df.f, gene_id == "CEP290"),
      #   aes(label = gene_id),
      #   segment.size = 1,
      #   segment.color = "royalblue1",
      #   box.padding = 0.35,
      #   point.padding = 0.5
      #   # box.padding = unit(0.4, "lines"),
      #   # point.padding = unit(0.4, "lines")
      # )
  ggsave(p, filename = outpdf, width = out_width, height = out_height)
  
}








