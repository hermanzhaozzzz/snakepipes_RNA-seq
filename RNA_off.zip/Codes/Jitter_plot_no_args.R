library(tidyverse)
library(ggplot2)

# args <- commandArgs(trailingOnly = TRUE)

### change by case ###
### use final sites file directly
pmat_file_path <- "Cmax/"
file_pattern <- ".txt"
sample_pattern <- "_M6C30R0"
mut_count_cutoff <- 6
cover_count_cutoff <- 30
mut_ratio_cutoff <- 0
fwd_mut <- "CT"
rev_mut <- "GA"
samples <- c("PGT","PGTLiu","PGT73","PGT7396")
colors <- c("#ade8f4","#023e8a","#0096c7","#48cae4")
out_pdf <- "Cmax/Cmax_CT.pdf"


### not change ###
xintercept <- c(0)
pdf_height <- 12
pdf_width <- 16
pmat_type <- "pvalue_pmat"


Jitter_pmat_plot <- function(pmat_path,file_pattern="pmat",case_pattern="_Aligned",
                             mut_count,cover_count,mut_ratio,fwd_mut,
                             rev_mut,samples_level,samples_color,xintercept_loc=c(0),
                             out_pdf_file,out_pdf_height=4,out_pdf_width=12,pmat_type="raw_pmat"){
  pmat_path = pmat_path
    
    
  if (pmat_type == "raw_pmat"){
      cols <- c("chr","start","end","site_idx",
            "A_count","G_count","C_count","T_count",
            "mut_type","From","To","ref_num","Mut_num","Cover_num","raw_mut_ratio")
  }else if (pmat_type == "pvalue_pmat"){
      cols <- c("chr","start","end","sample_idx","bedcol5","strand","site_idx",
            "A_count","G_count","C_count","T_count","mut_type","From","To","ref_num",
                "Mut_num","Cover_num","raw_mut_ratio","pvalue","qvalue","sample","mut_ratio")
  }
  
  
  # print(cols)
    
  Merge_ls <- list()
  filenames <- list.files(pmat_path, pattern=str_c("*.",file_pattern), full.names=TRUE)
  # print(filenames)
    
  for (i in 1:length(filenames)){
    tmp <- str_split(filenames[[i]],"/")[[1]]
    file <- tmp[length(tmp)]
    case <- str_split(file, case_pattern)[[1]][1] ### pattern for split out the samples name ###
    
    # print(case)
    # df <- read.table(filenames[[i]], sep="\t",col)
    df <- read.csv(filenames[[i]],sep = "\t",col.names = cols,header = F)
    
    if (is_empty(df$chr)){
      if (pmat_type == "raw_pmat"){
          df <- data.frame("chr_name",1,10,"site_index",0,0,0,0,
                       "aa","a","a",0,0,0,0,1,1)
          colnames(df) <- cols
      }else if (pmat_type == "pvalue_pmat"){
          df <- data.frame("chr_name",1,10,"case_idx",".","+","site_index",0,0,0,0,
                       "aa","a","a",0,0,0,0,1,1,"sample",0)
          colnames(df) <- cols
      }
    }else{
      df <- df
    }
      
    if (pmat_type == "raw_pmat"){
        df[, c(10,11)] <- sapply(df[, c(10,11)], as.character)
    }else if (pmat_type == "pvalue_pmat"){
        df[, c(13,14)] <- sapply(df[, c(14,15)], as.character)
    }
       
    # print(df)
      
    # colnames(df) <- cols
    df_f <- mutate(df, mut_ratio = raw_mut_ratio*100, Sample = case)
    
    Merge_ls[[i]] <- df_f
  }
  
  Strip_df <- bind_rows(Merge_ls)
  # Strip_df$Sample <- factor(Strip_df$Sample, levels = unique(Strip_df$Sample))
  # Strip_df$Sample <- factor(Strip_df$Sample, levels = Samples_Level)
  
  ### ######################################################################################### ###
  ### Step2: Set the cutoffs: Mut_number, Cover_number, MUt_ratio for filt sites and jitterplot ###
  ### ######################################################################################### ###
  mut_cutoff = mut_count
  cover_cutoff = cover_count
  ratio_cutoff = mut_ratio
  
  Filt_df <- Strip_df %>% filter(Mut_num >= mut_cutoff &
                                   Cover_num >= cover_cutoff &
                                   mut_ratio >= ratio_cutoff)
  
  Filt_df.mut <- Filt_df %>% filter(mut_type == fwd_mut | mut_type == rev_mut)
  # Filt_df.mut$Sample <- factor(Filt_df.mut$Sample, levels = unique(Strip_df$Sample))
  Samples_Level <- samples_level
  color_value <- samples_color
  
  Filt_df.mut$Sample <- factor(Filt_df.mut$Sample, levels = Samples_Level)
  
  Case_ls <- unique(Strip_df$Sample)
  
  p <- ggplot(Filt_df.mut,aes(x=Sample,y=mut_ratio,color=Sample,alpha=Sample))+
    geom_jitter()+
    # scale_color_brewer(palette="Set3")+
    # scale_fill_gradient2(low = "#264653", mid = "#e9c46a",high = "#e76f51", na.value = NA)+
    # scale_color_manual(values = (colorRampPalette(brewer.pal(11,"Spectral"))(length(Case_ls))))+
    scale_color_manual(values = color_value, drop=FALSE)+
    scale_alpha_manual(values = rep(c(1),each=length(Case_ls)))+
    scale_y_continuous(limits = c(0,120),breaks=seq(0,120,20),expand=c(0,0))+
    # theme(panel.background = element_rect(fill = "white", colour = "black", size = 0.5))+
    theme_bw()+
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.border = element_rect(colour = "black", fill=NA, size=1))+
    theme(axis.title.x=element_blank(),
          axis.text.x = element_text(angle = 45, vjust=1, hjust=1, size=10))+
          # axis.text.x =element_blank(),
          # axis.ticks.x=element_blank())+
    theme(legend.position = "none")+
    # theme(axis.text.y = element_text(angle = 0, vjust = 1, hjust=1, size = 14))+
    theme(axis.text.y = element_text(hjust = 0.4,size = 15),
          axis.title.y=element_blank(),
          axis.ticks.length.y = unit(.25, "cm"))+
    annotate("text",
             x = 1:length(table(Strip_df$Sample)),
             # y = aggregate(Strip_df$mut_ratio_percentage ~ Strip_df$Sample, Strip_df, median)[ , 2],
             y = 110,
             label = table(Filt_df.mut$Sample),
             col = "black",
             vjust = - 1, size = 5)+
    # xlab("")+
    # ylab("Mutation Ratio (%)")+
    # ggtitle(str_c("AG-TC mutation off-target sites count"))+
    scale_x_discrete(drop=FALSE)+
    geom_vline(xintercept=xintercept_loc, 
               color = "grey", size=0.5)
  
  ggsave(p, filename = out_pdf_file,
         height = out_pdf_height, width = out_pdf_width, limitsize = FALSE)
}


Jitter_pmat_plot(pmat_path = pmat_file_path, file_pattern = file_pattern,
                 case_pattern = sample_pattern, mut_count = mut_count_cutoff,
                 cover_count = cover_count_cutoff, mut_ratio = mut_ratio_cutoff,
                 fwd_mut = fwd_mut, rev_mut = rev_mut, samples_level = samples,
                 samples_color = colors, xintercept_loc = xintercept,out_pdf_file = out_pdf, 
                 out_pdf_height = pdf_height, out_pdf_width = pdf_width, pmat_type = pmat_type)

