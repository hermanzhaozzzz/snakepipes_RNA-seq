#!/usr/bin/env python

import pysam
import argparse

if __name__ == '__main__':
	parser = argparse.ArgumentParser(description="Remove low cover site in ctrls")
	parser.add_argument("-path","--bam_path", help="Input the bam files path", required=True)
	parser.add_argument("-s","--samples_name", help="Input the samples name link with choma", required=True)
	parser.add_argument("-pmat","--input_pmat", help="The raw pmat file", required=True)
	parser.add_argument("-c","--cover_cutoff", help="The cover cutoff used", required=True)
	parser.add_argument("-o","--output", help="The output file contain filtered sites", required=True)
	
	ARGS = parser.parse_args()
	
	bam_path = ARGS.bam_path
	samples = ARGS.samples_name
	pmat = ARGS.input_pmat
	cover_cutoff = int(ARGS.cover_cutoff)
	output = ARGS.output
	
	if bam_path[-1] != "/":
		bam_path = bam_path + "/"
	else:
		bam_path = bam_path

	bams = [bam_path+i+"_Aligned_sort_MarkDup_rmdup_Q20_FiltClip_downsample.bam" for i in samples.split(",")]
	bams_prj = [pysam.AlignmentFile(i) for i in bams]

	site_file = open(pmat)

	out = open(output,"w")
	for lines in site_file.readlines():

		judge = []
		info = []

		line = lines.strip()
		chrom, site = line.split("\t")[0], int(line.split("\t")[1])

		for bam_prj in bams_prj:
			n_array = bam_prj.count_coverage(chrom,site,site+1)
			n_list = [j[0] for j in [list(i) for i in list(n_array)]]
			cover = int(sum(n_list)/2)
			info.append(str(cover))
			if cover >= cover_cutoff:
				judge.append("Yes")
			else:
				judge.append("No")

		count_No = judge.count("No")
		if count_No < len(bams_prj)/2:
	#		 print(count_No)
			out.write(lines)
	out.close()