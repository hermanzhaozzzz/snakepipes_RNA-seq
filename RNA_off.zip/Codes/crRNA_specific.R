library(tidyverse)
library(ggseqlogo)

args <- commandArgs(trailingOnly = TRUE)
sample1_name <- args[1]
sample1_pmat <- args[2]
sample1_motif <- args[3]
sample2_name <- args[4]
sample2_pmat <- args[5]
sample2_motif <- args[6]
out_pdf_file <- args[7]
out_pdf_width <- as.integer(args[8])
out_pdf_height <- as.integer(args[9])
out_file_path <- args[10]
motif_method <- args[11] # "bits" or "prob"

# sample1_name <- "Rewrite"
# sample1_pmat <- "LEL-TadA_V82T-F84I-Y147R_TAG-repoter_M3C15R0_AG_TC_filter.txt"
# sample1_motif <- "LEL-TadA_V82T-F84I-Y147R_TAG-repoter_Extend_l22r22_RNA.txt"
# sample2_name <- "Evector"
# sample2_pmat <- "Evector_M3C15R0_AG_TC_filter.txt"
# sample2_motif <- "Evector_Extend_l22r22_RNA.txt"
# out_pdf_file <- "Out_pdf.pdf"
# out_pdf_width <- 10
# out_pdf_height <- 12
# out_file_path <- "."


pmat_col <- c("chrom","start","end","sample_idx","bedcol4","strand",
              "site_idx","A_num","G_num","C_num","T_num","mut_type","mut_from","mut_to",
              "mut_num","ref_num","cover_num","raw_mut_ratio","pvalue","qvalue","sample","mut_ratio")


if (file.info(sample1_pmat)$size == 0){
    s1 <- data.frame(matrix(ncol = length(pmat_col)+1, nrow = 0))
    colnames(s1) <- c(pmat_col,"Extend_motif")
    s1[nrow(s1) + 1,] = c("chrN",0,0,"chrN_0_0",".","+",
              "chrN_0_0",0,0,0,0,"NN","N","N",
              0,0,0,0,1,1,sample1_name,0,"NNNNNN")
}else{
    s1_pmat <- read.csv(sample1_pmat,sep = "\t",col.names = pmat_col,header = F)
    s1_extend_motif <- read.csv(sample1_motif,sep = "\t",col.names = "Extend_motif",header = F)
    s1 <- cbind(s1_pmat, s1_extend_motif)
}

if (file.info(sample2_pmat)$size == 0){
    s2 <- data.frame(matrix(ncol = length(pmat_col)+1, nrow = 0))
    colnames(s2) <- c(pmat_col,"Extend_motif")
    s2[nrow(s2) + 1,] = c("chrN",0,0,"chrN_0_0",".","+",
              "chrN_0_0",0,0,0,0,"NN","N","N",
              0,0,0,0,1,1,sample2_name,0,"NNNNNN")
}else{
    s2_pmat <- read.csv(sample2_pmat,sep = "\t",col.names = pmat_col,header = F)
    s2_extend_motif <- read.csv(sample2_motif,sep = "\t",col.names = "Extend_motif",header = F)
    s2 <- cbind(s2_pmat,s2_extend_motif)
}

if (file.info(sample1_pmat)$size == 0 && file.info(sample2_pmat)$size == 0){
    s1 <- data.frame(matrix(ncol = length(pmat_col)+1, nrow = 0))
    s2 <- data.frame(matrix(ncol = length(pmat_col)+1, nrow = 0))
    
    colnames(s1) <- c(pmat_col,"Extend_motif")
    colnames(s2) <- c(pmat_col,"Extend_motif")
    
    s1[nrow(s1) + 1,] = c("chrN",0,0,"chrN_0_0",".","+","chrN_0_0",0,0,0,0,"NN","N","N",0,0,0,0,1,1,sample1_name,0,"NNNNNN")
    s2[nrow(s2) + 1,] = c("chrN",0,0,"chrN_0_0",".","+","chrN_0_0",0,0,0,0,"NN","N","N",0,0,0,0,1,1,sample2_name,0,"NNNNNN")
}

# print(s1)
# print(s2)


s1_site_idx <- s1$site_idx
s2_site_idx <- s2$site_idx

overlap <- intersect(s1_site_idx, s2_site_idx)
s1_specific <- setdiff(s1_site_idx,s2_site_idx)
s2_specific <- setdiff(s2_site_idx,s1_site_idx)

# colnames(s1)
overlap_df <- s1 %>% filter(
  site_idx %in% overlap
)
s1_specific_df <- s1 %>% filter(
  site_idx %in% s1_specific
)
s2_specific_df <- s2 %>% filter(
  site_idx %in% s2_specific
)

# df <- data.frame()
if (is_empty(overlap_df$chrom)){
  overlap_df <- data.frame (sample1_name = c("No overlap"),
                    sample2_name = c("No overlap"))
  # overlap_motif <- c(paste(rep("N",motif_len),collapse = ""))
  overlap_motif <- c("NNNNNN")
}else{
  overlap_df <- overlap_df
  overlap_motif <- overlap_df$Extend_motif
}

if (is_empty(s1_specific_df$chrom)){
  s1_specific_df <- data.frame (sample1_name = c(str_c(sample1_name," has not specific site")))
  s1_specific_motif <- c("NNNNNN")
}else{
  s1_specific_df <- s1_specific_df
  s1_specific_motif <- s1_specific_df$Extend_motif
}

if (is_empty(s2_specific_df$chrom)){
  s2_specific_df <- data.frame (sample2_name = c(str_c(sample2_name," has not specific site")))
  s2_specific_motif <- c("NNNNNN")
}else{
  s2_specific_df <- s2_specific_df
  s2_specific_motif <- s2_specific_df$Extend_motif
}

write.table(overlap_df,file = str_c(out_file_path,"/",sample1_name,"_vs_",sample2_name,"_overlap_motif.txt"),quote = F,sep = "\t",col.names = F,row.names = F)
write.table(s1_specific_df,file = str_c(out_file_path,"/",sample1_name,"_specific_motif.txt"),quote = F,sep = "\t",col.names = F,row.names = F)
write.table(s2_specific_df,file = str_c(out_file_path,"/",sample2_name,"_specific_motif.txt"),quote = F,sep = "\t",col.names = F,row.names = F)

# print(overlap_df)
# print(s1_specific_df)
# print(s2_specific_df)

# print(overlap_motif)
# print(s1_specific_motif)
# print(s2_specific_motif)



merge_motif <- list(as.character(s1$Extend_motif),as.character(s2$Extend_motif),
                    as.character(overlap_motif),as.character(s1_specific_motif),as.character(s2_specific_motif))
show_name <- c(str_c(sample1_name,"_all_sites (",length(s1$Extend_motif),")"),
               str_c(sample2_name,"_all_sites (",length(s2$Extend_motif),")"),
               str_c("Overlap_motif (",length(overlap_motif),")"),
               str_c(sample1_name,"_specific_motif (",length(s1_specific_motif),")"),
               str_c(sample2_name,"_specific_motif (",length(s2_specific_motif),")"))

merge_list <- list()
for (i in 1:length(merge_motif)){
  title_show <- show_name[[i]]
  table_use <- merge_motif[[i]]
  merge_list[[title_show]] <- table_use
}
p <- ggseqlogo(merge_list, ncol = 1, method=motif_method)+theme_bw()+theme_classic()
ggsave(p,filename = out_pdf_file,height = out_pdf_height, width = out_pdf_width)














