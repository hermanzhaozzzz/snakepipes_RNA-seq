#!/usr/bin/ python
# -*- coding: utf-8 -*-

# ------------------------------------------------------------------------------------------>>>>>>>>>>
# packages
# ------------------------------------------------------------------------------------------>>>>>>>>>>
import argparse
import time
import subprocess
from concurrent.futures import ProcessPoolExecutor
# ------------------------------------------------------------------------------------------>>>>>>>>>>
# functions
# ------------------------------------------------------------------------------------------>>>>>>>>>>
def gatk4(chrom):
    subprocess.run([args.gatk, '--java-options', '-Xmx80G', 'HaplotypeCaller', '-I', args.input,
                    '-O', args.output + '.part-' + chrom + '.g.vcf.gz','-R',args.ref,
                    '--dont-use-soft-clipped-bases','--emit-ref-confidence','GVCF','-OVI','False', '-L',chrom],shell=False)
if __name__ == '__main__':
    # ------------------------------------------------------------------------------------------>>>>>>>>>>
    # argparse
    # ------------------------------------------------------------------------------------------>>>>>>>>>>
    parser = argparse.ArgumentParser(description='GATK4 HaplotypeCaller multiprocess calculate')
    parser.add_argument('--gatk', '-G', help='GATK4 path', required=True)
    parser.add_argument('--process', '-P', type=int, help='Thread needed', required=True)
    parser.add_argument('--input', '-I', help='bam file', required=True)
    parser.add_argument('--ref', '-R', help='reference genome', required=True)
    parser.add_argument('--output', '-O', help='output g.vcf.gz file', required=True)
    args = parser.parse_args()
    
    commom_human_chrom = [
        'chr1', 'chr2', 'chr3', 'chr4', 'chr5', 'chr6', 'chr7', 'chr8', 'chr9', 'chr10', 'chr11', 'chr12', 'chr13', 'chr14', 'chr15', 'chr16', 'chr17', 'chr18', 'chr19', 'chr20', 'chr21', 'chr22', 'chrX', 'chrY'
    ]
    print("默认拆分模式：%s" % '\n'.join(commom_human_chrom))
    # ------------------------------------------------------------------------------------------>>>>>>>>>>
    # subprocess
    # ------------------------------------------------------------------------------------------>>>>>>>>>>
    chrom_gvcf = []
    
    for chrom in commom_human_chrom:
        chrom_gvcf.append( args.output + '.part-' + chrom + '.g.vcf.gz')
    try:
        with ProcessPoolExecutor(max_workers=args.process) as pool:
            future1 = pool.map(gatk4,commom_human_chrom)
            print(list(future1))
    except Exception as e: 
        print(e)
    print("*********\n" * 3)
    print("HaplotypeCaller subtasks were done!\nSleep for 10 seconds")
    print("*********\n" * 3)
    time.sleep(10)
    print("*********\n" * 3)
    print("Start to merge g.vcfs...")
    print("*********\n" * 3)
    subprocess.run(args.gatk + ' GatherVcfs -RI TRUE -I ' + ' -I '.join(chrom_gvcf) + ' -O ' + args.output, shell=True)
    subprocess.run('rm -rf ' + ' '.join(chrom_gvcf),shell=True)

    