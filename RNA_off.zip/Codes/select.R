library(tidyverse)

case_ls <- c("ADS_BE1_rep1","ADS_BE1_rep2",
             "eADS_BE2_rep1","eADS_BE2_rep2",
             "nCas9_rep1","nCas9_rep2",
             "BE4max_rep1","BE4max_rep2",
             "YE1_rep1","YE1_rep2",
             "zh144_rep1","zh144_rep2",
             "zh224_rep1_down35M","zh224_rep2_down35M",
             "zh230_rep1_down35M","zh230_rep2_down35M")
Pos_ls <- c("BE4max_rep1","BE4max_rep2",
            "YE1_rep1","YE1_rep2")

Sample_filt <- function(case_name, first_cutoff, mut_num_cutoff, cover_num_cutoff, fwd_mut, rev_mut,
                        outfolder,cutoff_type,ref_num_cutoff, mut_ratio_max){
  case <- case_name
  
  filename <- sprintf("%s_Aligned_%s_%s_%s.pmat", case, first_cutoff, fwd_mut, rev_mut)
  
  cols <- c("chr_name","chr_index_s","chr_index_e","site_index","A","G","C","T",
            "mut_type","ref_base","mut_base","ref_num","mut_num","cover_num","mut_ratio","pvalue","qvalue")
  
  cut1 <- read_tsv(filename,col_names = cols)
  
  cut2 <- cut1 %>% filter(
    mut_num >= mut_num_cutoff & 
      cover_num >= cover_num_cutoff & 
      mut_ratio >= 0.05 & 
      (mut_type == "CT" | mut_type == "GA") & 
      qvalue <= 0.001 &
      mut_ratio <= 0.99 & 
      ref_num >= ref_num_cutoff,
      mut_ratio <= mut_ratio_max)
  
  write_tsv(cut2, 
            file = sprintf("%s/%s_%s_M%sC%s_%s_%s_filter.txt",outfolder,case,cutoff_type,
                           mut_num_cutoff,cover_num_cutoff,fwd_mut,rev_mut), 
            col_names = F)
  
}

cutoff_for = "Soft"
fwd_mut_type = "AG"
rev_mut_type = "TC"

for (case in case_ls){
  if (("eADS" %in% case) | ("nCas9" %in% case) | ("ADS_BE1_rep1") %in% case){
    Sample_filt(case_name = case, mut_num_cutoff = 5, cover_num_cutoff = 30, first_cutoff = "M1C5_M1C5", mut_ratio_max = 0.99,
                fwd_mut = fwd_mut_type, rev_mut = rev_mut_type, outfolder = cutoff_for, cutoff_type = cutoff_for, ref_num_cutoff = 10)
  }else if ("ADS_BE1_rep2" %in% case){
    Sample_filt(case_name = case, mut_num_cutoff = 15, cover_num_cutoff = 30, first_cutoff = "M1C1R5Q0.001", mut_ratio_max = 0.25,
                fwd_mut = fwd_mut_type, rev_mut = rev_mut_type, outfolder = cutoff_for, cutoff_type = cutoff_for, ref_num_cutoff = 10)
  }else if (case %in% Pos_ls){
    Sample_filt(case_name = case, mut_num_cutoff = 5, cover_num_cutoff = 30, first_cutoff = "M1C5_M1C5", mut_ratio_max = 0.99,
                fwd_mut = fwd_mut_type, rev_mut = rev_mut_type, outfolder = cutoff_for, cutoff_type = cutoff_for, ref_num_cutoff = 0)
  }else {
    Sample_filt(case_name = case, mut_num_cutoff = 5, cover_num_cutoff = 30, first_cutoff = "M1C5_M1C5", mut_ratio_max = 0.99,
                fwd_mut = fwd_mut_type, rev_mut = rev_mut_type, outfolder = cutoff_for, cutoff_type = cutoff_for, ref_num_cutoff = 10)
  }
}



