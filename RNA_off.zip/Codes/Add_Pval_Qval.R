library(tidyverse)

args <- commandArgs(trailingOnly = TRUE)
pmat_file <- args[1]
out_file <- args[2]


load_colname = c(
  "chrom",
  "start",
  "end",
  "site_index",
  "A",
  "G",
  "C",
  "T",
  "mut_type",
  "ref_base",
  "mut_base",
  "ref_num",
  "mut_num",
  "cover_num",
  "mut_ratio",
  "pval",
  "qval"
)

pmat_df <- read_tsv(file = pmat_file, col_names = load_colname)

bg_pval = sum(pmat_df$mut_num) / sum(pmat_df$cover_num)
bg_cover = floor(sum(pmat_df$cover_num) / nrow(pmat_df))

pmat_df.mut <- filter(
  pmat_df,
  mut_num >= 3
)

pval = apply(pmat_df.mut, 1, FUN = function(input_row){
  res = binom.test(x =as.integer(input_row[13]) ,n = as.integer(input_row[14]), p = bg_pval, alternative = "greater")
  return(res$p.value)
})

pmat_df.mut.AddPval <- bind_cols(
  pmat_df.mut,
  pval = pval
)

# bg pval
pvalue_0 = binom.test(x =0 ,n = bg_cover, p = bg_pval, alternative = "greater")$p.value
pvalue_1 = binom.test(x =1 ,n = bg_cover, p = bg_pval, alternative = "greater")$p.value
pvalue_2 = binom.test(x =2 ,n = bg_cover, p = bg_pval, alternative = "greater")$p.value

match_index = match(pmat_df.mut.AddPval$site_index, pmat_df$site_index)

pmat_df.AddPval <- mutate(
  pmat_df,
  pval = case_when(
    mut_num == 0 ~ pvalue_0,
    mut_num == 1 ~ pvalue_1,
    mut_num == 2 ~ pvalue_2
  )
)

pmat_df.AddPval$pval[match_index] <- pmat_df.mut.AddPval$pval

qval <- p.adjust(pmat_df.AddPval$pval, method = "BH")

pmat_df.AddPval.AddFDR <- bind_cols(
  pmat_df.AddPval,
  qval = qval
)

write_tsv(pmat_df.AddPval.AddFDR, file = out_file, col_names = F)





