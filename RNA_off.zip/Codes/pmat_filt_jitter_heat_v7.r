library(tidyverse)
library(RColorBrewer)
library(gridExtra)
library(ggplot2)
library(stringi)
library(ComplexHeatmap)
library(circlize)
library(scales)

### ====================================================== ###
###                        Conglog                         ###
### ====================================================== ###
### v2 update: 2022-02-15 add combination mutation jitter plot and filter output

### ====================================================== ###
###               Pass variables from shell                ###
### ====================================================== ###
args <- commandArgs(trailingOnly = TRUE)
pmat_path_in <- args[1]
file_pattern <- args[2]
# fwd_mut <- as.character(args[2])
# rev_mut <- as.character(args[3])
mut_combination <- as.list(unlist(str_split(args[3],",")))
mut_count <- as.integer(args[4])
cover_reads <- as.integer(args[5])
mut_ratio_cutoff <- as.double(args[6])
max_cover_count <- as.character(args[7])
qvalue_cutoff <- as.double(args[8])
case_split_pattern <- as.character(args[9])
output_path_in <- args[10]
Sample_levels <- as.character(unlist(str_split(args[11],",")))
Sample_colors <- as.character(str_c("#",unlist(str_split(args[12],","))))
output_jitter_pdf_name <- args[13]
out_jitter_height <- as.integer(args[14])
out_jitter_width <- as.integer(args[15])
output_mutheat_pdf_name <- args[16]
out_mutheat_height <- as.integer(args[17])
out_mutheat_width <- as.integer(args[18])
mut_heat_color <- as.character(args[19])
mut_heat_value <- as.numeric(unlist(str_split(args[20],","))) #scales::rescale(c(0, 6,7,8,9,10,11,12,13,15)) 这里就是c(0,6,7,8,9,10,11,12,13,15)这个
mut_heat_lebel <- as.numeric(unlist(str_split(args[21],","))) # c(0,10,100,1000,10000)
ylim_max <- as.numeric(args[22])
label_pos <- as.numeric(args[23])
xintercept <- as.numeric(unlist(str_split(args[24],",")))
header_type <- args[25] ## "raw" or "add"

# print(mut_combination)
# print(Sample_levels)
# print(Sample_colors)

# heat_value <- c(0,50,100)
# heat_color <- c("#E0AAFF","#9D4EDD","#5A189A")

Colors_values <- setNames(Sample_colors,Sample_levels) ### Important tip: add Names for a vector!
# print(class(Colors_values))

Pure_path <- function(input_str){
  last_c <-  substr(input_str,nchar(input_str)- 1 + 1, nchar(input_str))
  except_last_c <-  substr(input_str,1,nchar(input_str)-1)
  
  if (last_c == "/"){
    out_str <- except_last_c
  }else{
    out_str <- input_str
  }
  return(out_str)
}

pmat_path <-  Pure_path(pmat_path_in)
output_path <- Pure_path(output_path_in)

dir.create(output_path)

if (max_cover_count == "Unlimited"){
    max_cover_count = 1000000000
}else{
    max_cover_count = as.integer(max_cover_count)
}

### ====================================================== ###
###       Filt each sample based on cutoffs from pmat      ###
### ====================================================== ###
filenames <- list.files(pmat_path, pattern=str_c("*",file_pattern), full.names=TRUE)
for (i in 1:length(filenames)){
  tmp <- str_split(filenames[[i]],"/")[[1]]
  file <- tmp[length(tmp)]
  case <- unlist(str_split(file, case_split_pattern))[1] ## spli pattern, default = "__" 双下划线
  
  # print(case)
  cols_raw <- c("chr_name","chr_index_s","chr_index_e","site_index","A","G","C","T",
            "mut_type","ref_base","mut_base","ref_num","mut_num","cover_num","mut_ratio","pvalue","qvalue")
    
  cols_add <- c("chr_name","chr_index_s","chr_index_e","IDs","bed_col5","Orientation","site_index","A","G","C","T",
            "mut_type","ref_base","mut_base","ref_num","mut_num","cover_num","mut_ratio","pvalue","qvalue","Sample","mut_ratio_percentage")
  
  if (length(readLines(filenames[[i]]))==0){
      if (header_type == "raw"){
          df <- data.frame("chr_name",1,10,"site_index",0,0,0,0,
                                        "NN","N","N",0,0,0,0,1,1)
      }else if (header_type == "add"){
          df <- data.frame("chr_name",0,0,"ID",".","ori","idx",0,0,0,0,"NN","N","N",
                           0,0,0,0,0,0,"sample",0)
      }
  }else{
      df <- read.table(filenames[[i]], sep="\t")
  }
  
  
  if (header_type == "raw"){
      df <- df
      colnames(df) <- cols_raw
  }else if (header_type == "add"){
      colnames(df) <- cols_add
      df <- subset(df, select = -c(IDs,bed_col5,Orientation,Sample,mut_ratio_percentage))
  }
    
    
  if (dim(df)[1] == 0){
    df <- data.frame("chr_name",1,10,"site_index",0,0,0,0,
                                        "NN","N","N",0,0,0,0,1,1)
    colnames(df) <- cols_raw
  }else{
    df <- df
  }
  # colnames(df) <- cols_raw
  df <- df %>% mutate(Sample = case, mut_ratio_percentage = mut_ratio*100)
  df <- df %>% mutate(IDs = str_c(case,site_index,sep="__"), .after=chr_index_e)
  df <- df %>% mutate(bed_col5=".", .after=IDs)
  df <- filter(df, mut_num >= mut_count & cover_num >= cover_reads & cover_num <= max_cover_count & 
             mut_ratio_percentage>=mut_ratio_cutoff & qvalue <= qvalue_cutoff)
  
  for (i in 1:length(mut_combination)){
    mut = mut_combination[[i]]
    fwd_mut = unlist(str_split(mut,"-"))[1]
    rev_mut = unlist(str_split(mut,"-"))[2]
    
    df_f <- filter(df, mut_type == fwd_mut | mut_type == rev_mut)
    df_f <- df_f %>% mutate(Orientation = ifelse(mut_type==fwd_mut,"+","-"), .after=bed_col5)
      
    write.table(df_f,file = str_c(output_path,"/",case,
                                  "_M",mut_count,"C",cover_reads,"R",mut_ratio_cutoff,
                                  "_",fwd_mut,"_",rev_mut,"_filter.txt"),
                quote = F,sep = "\t",row.names = F,col.names = F)
    
  }
    
  mut_stats <- c()
  # mut_combination <- c("AG-TC", "CT-GA")
  for (i in 1:length(mut_combination)){
    mut = mut_combination[[i]]
    fwd_mut = unlist(str_split(mut,"-"))[1]
    rev_mut = unlist(str_split(mut,"-"))[2]

    mut_stats <- c(mut_stats, fwd_mut, rev_mut)
  }
  df_fl <- filter(df, !mut_type %in% mut_stats)
  df_fl <- mutate(df_fl, Orientation = "None",.after=bed_col5)
  write.table(df_fl,file = str_c(output_path,"/",case,
                                   "_M",mut_count,"C",cover_reads,"R",mut_ratio_cutoff,
                                   "_filter_other_mut.txt"),
                quote = F,sep = "\t",row.names = F,col.names = F)
    
}

### ====================================================== ###
###                 Jitter and mutheat plots               ###
### ====================================================== ###
Plot_cutoff_mut_heat_jitter_plots <- function(pmat_path, file_pattern="pmat",
                                             case_split_pattern="__",
                                             mutation_combine,
                                             mut_number_cutoff=0, cover_num_cutoff=0, 
                                             max_cover_cutoff=1000000000, mut_ratio_cutoff=0,
                                             Samples_Level,color_value,
                                             jitter_plot_pdf, jitter_height, jitter_width,
                                             mut_heatmap_pdf, mut_heatmap_height, mut_heatmap_width,
                                             mut_heat_color="Purples", mut_heat_values, mut_heat_lebels,
                                             y_max=120,label_pos=105,xintercept_loc=c(0)){
  
  ### ######################################################################################### ###
  ###                               Step1: deal with the raw pmat files                         ###
  ### ######################################################################################### ###
  pmat_path = pmat_path
  cols_raw <- c("chr","start","end","site_idx","A_count","G_count","C_count","T_count",
            "mut_type","From","To","ref_num","Mut_num","Cover_num","raw_mut_ratio","pvalue","qvalue")
  cols_add <- c("chr","start","end","IDs","bed_col5","Orientation","site_idx","A_count","G_count","C_count","T_count",
            "mut_type","From","To","ref_num","Mut_num","Cover_num","raw_mut_ratio","pvalue","qvalue","Sample","mut_ratio_percentage")
  
  Merge_ls <- list()
  filenames <- list.files(pmat_path, pattern=str_c("*",file_pattern), full.names=TRUE)
  for (i in 1:length(filenames)){
    tmp <- str_split(filenames[[i]],"/")[[1]]
    file <- tmp[length(tmp)]
    case <- str_split(file, case_split_pattern)[[1]][1] ### pattern for split out the samples name ###
    
    # print(case)
    if (length(readLines(filenames[[i]]))==0){
      if (header_type == "raw"){
          df <- data.frame("chr_name",1,10,"site_index",0,0,0,0,
                                        "NN","N","N",0,0,0,0,1,1)
      }else if (header_type == "add"){
          df <- data.frame("chr_name",0,0,"ID",".","ori","idx",0,0,0,0,"NN","N","N",
                           0,0,0,0,0,0,"sample",0)
      }
    }else{
      df <- read.table(filenames[[i]], sep="\t")
    }
      
    if (header_type == "raw"){
      df <- df
      colnames(df) <- cols_raw
    }else if (header_type == "add"){
      colnames(df) <- cols_add
      df <- subset(df, select = -c(IDs,bed_col5,Orientation,Sample,mut_ratio_percentage))
    }
      
    if (dim(df)[1] == 0){
      df <- data.frame("chr_name",1,10,"site_index",0,0,0,0,
                       "NN","N","N",0,0,0,0,1,1)
      colnames(df) <- cols_raw
    }else{
      df <- df
    }
    
    df[, c(10,11)] <- sapply(df[, c(10,11)], as.character)
    # colnames(df) <- cols_raw
    # df <- data.frame(lapply(df, function(x){
    #   gsub("\tTRUE\t", "T", x)
    # }))
    # print(df)
    
    df_f <- mutate(df, mut_ratio = raw_mut_ratio*100, Sample = case)
    
    Merge_ls[[i]] <- df_f
    
  }
  # print(Merge_ls[6])
  # print(Merge_ls[7])
  Strip_df <- bind_rows(Merge_ls)
  # Strip_df$Sample <- factor(Strip_df$Sample, levels = unique(Strip_df$Sample))
  # Strip_df$Sample <- factor(Strip_df$Sample, levels = Samples_Level)
  
  ### ######################################################################################### ###
  ### Step2: Set the cutoffs: Mut_number, Cover_number, MUt_ratio for filt sites and jitterplot ###
  ### ######################################################################################### ###
  mut_cutoff = mut_number_cutoff
  cover_cutoff = cover_num_cutoff
  ratio_cutoff = mut_ratio_cutoff
  
  Filt_df <- Strip_df %>% filter(Mut_num >= mut_cutoff &
                                   Cover_num >= cover_cutoff &
                                   Cover_num <= max_cover_cutoff &
                                   mut_ratio >= ratio_cutoff &
                                   qvalue <= qvalue_cutoff)
  
  # write.table(Filt_df, cutoff_filt_file, col.names = T, row.names = F, quote = F, sep = "\t")
  
  all_mut <- unique(Strip_df$mut_type)
  
  jitter_plot_merge <- list()
  for (i in 1:length(all_mut)){
    mut <- all_mut[i]
    
    Filt_df.mut <- Filt_df %>% filter(mut_type == mut)
    # Filt_df.mut$Sample <- factor(Filt_df.mut$Sample, levels = unique(Strip_df$Sample))
    Filt_df.mut$Sample <- factor(Filt_df.mut$Sample, levels = Samples_Level)
    
    Case_ls <- unique(Strip_df$Sample)
    # Case_ls <- Samples_Level
    
    if (dim(Filt_df.mut)[1] == 0){
      df <- data.frame(Sample=Case_ls,
                       mut_ratio=rep(c(110),length(Case_ls)))
      p <- ggplot(df,aes(x=Sample,y=mut_ratio,color=Sample)) + 
        geom_jitter(size=2,stroke=0)+
        ylim(c(0,103))+
        scale_color_manual(values = color_value, drop=FALSE)+
#         theme(panel.background = element_rect(fill = "white", colour = "black", size = 2))+
        theme_bw()+
        theme(panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              panel.border = element_rect(colour = "black", fill=NA, size=2))+
        theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1, size = 14))+
        annotate("text",
                 x = 1:length(table(Strip_df$Sample)),
                 # y = aggregate(Strip_df$mut_ratio_percentage ~ Strip_df$Sample, Strip_df, median)[ , 2],
                 y = 101,
                 label = "0",
                 col = "black",
                 vjust = - 1, size = 4)+
        xlab("")+
        ylab("Mutation Ratio (%)")+
        ggtitle(str_c("Filt mut type: ",mut, " is empty site"))+
        scale_x_discrete(drop=FALSE)
      jitter_plot_merge[[i]] <- p
    }else{
      p <- ggplot(Filt_df.mut,aes(x=Sample,y=mut_ratio,color=Sample,alpha=Sample))+
        geom_jitter(size=2,stroke=0)+
        # scale_color_brewer(palette="Set3")+
        # scale_fill_gradient2(low = "#264653", mid = "#e9c46a",high = "#e76f51", na.value = NA)+
        # scale_color_manual(values = (colorRampPalette(brewer.pal(11,"Spectral"))(length(Case_ls))))+
        scale_color_manual(values = color_value, drop=FALSE)+
        scale_alpha_manual(values = rep(c(1),each=length(Case_ls)))+
        scale_y_continuous(limits = c(0,y_max),breaks=seq(0,y_max,20))+
#         theme(panel.background = element_rect(fill = "white", colour = "black", size = 2))+
        theme_bw()+
        theme(panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              panel.border = element_rect(colour = "black", fill=NA, size=1))+
        theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1, size = 14))+
        theme(legend.position = "none")+
        theme(axis.text.y = element_text(angle = 0, vjust = 1, hjust=1, size = 14))+
        theme(axis.text.y = element_text(hjust = 0.4,size = 15),
              axis.title.y=element_blank(),
              axis.ticks.length.y = unit(.25, "cm"))+
        annotate("text",
                 x = 1:length(table(Strip_df$Sample)),
                 # y = aggregate(Strip_df$mut_ratio_percentage ~ Strip_df$Sample, Strip_df, median)[ , 2],
                 y = label_pos,
                 label = table(Filt_df.mut$Sample),
                 col = "black",
                 vjust = - 1, size = 5)+
        xlab("")+
        ylab("Mutation Ratio (%)")+
        ggtitle(str_c(mut," mutation off-target sites count"))+
        scale_x_discrete(drop=FALSE)+
        geom_vline(xintercept=xintercept_loc, 
                   color = "grey", size=0.5)
      
      # p
      jitter_plot_merge[[i]] <- p
    }
  }
  
  ### Plot combination mutation jitter plot ###
  for (i in 1:length(mutation_combine)){
    mut = mutation_combine[[i]]
    fwd_mut = unlist(str_split(mut,"-"))[1]
    rev_mut = unlist(str_split(mut,"-"))[2]
    
    Filt_df.mut <- Filt_df %>% filter(mut_type == fwd_mut | mut_type == rev_mut)
    # Filt_df.mut$Sample <- factor(Filt_df.mut$Sample, levels = unique(Strip_df$Sample))
    Filt_df.mut$Sample <- factor(Filt_df.mut$Sample, levels = Samples_Level)
    
    Case_ls <- unique(Strip_df$Sample)
    # Case_ls <- Samples_Level
    
    if (dim(Filt_df.mut)[1] == 0){
      df <- data.frame(Sample=Case_ls,
                       mut_ratio=rep(c(110),length(Case_ls)))
      p <- ggplot(df,aes(x=Sample,y=mut_ratio,color=Sample)) + 
        geom_jitter()+
        ylim(c(0,103))+
        scale_color_manual(values = color_value, drop=FALSE)+
#         theme(panel.background = element_rect(fill = "white", colour = "black", size = 2))+
        theme_bw()+
        theme(panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              panel.border = element_rect(colour = "black", fill=NA, size=2))+
        theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1, size = 14))+
        annotate("text",
                 x = 1:length(table(Strip_df$Sample)),
                 # y = aggregate(Strip_df$mut_ratio_percentage ~ Strip_df$Sample, Strip_df, median)[ , 2],
                 y = 101,
                 label = "0",
                 col = "black",
                 vjust = - 1, size = 4)+
        xlab("")+
        ylab("Mutation Ratio (%)")+
        ggtitle(str_c("Filt mut type: ",mut, " is empty site"))+
        scale_x_discrete(drop=FALSE)
        
      ggsave(p,file=str_c(jitter_plot_pdf,"_Only_",fwd_mut,"_",rev_mut,".pdf"),
            height=10, width=1*length(Case_ls)+1.5,limitsize=FALSE)
        
      jitter_plot_merge[[length(all_mut)+i]] <- p
    }else{
      p <- ggplot(Filt_df.mut,aes(x=Sample,y=mut_ratio,color=Sample,alpha=Sample))+
        geom_jitter(size=2,stroke=0)+
        # scale_color_brewer(palette="Set3")+
        # scale_fill_gradient2(low = "#264653", mid = "#e9c46a",high = "#e76f51", na.value = NA)+
        # scale_color_manual(values = (colorRampPalette(brewer.pal(11,"Spectral"))(length(Case_ls))))+
        scale_color_manual(values = color_value, drop=FALSE)+
        scale_alpha_manual(values = rep(c(1),each=length(Case_ls)))+
        scale_y_continuous(limits = c(0,y_max),breaks=seq(0,y_max,20))+
#         theme(panel.background = element_rect(fill = "white", colour = "black", size = 2))+
        theme_bw()+
        theme(panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              panel.border = element_rect(colour = "black", fill=NA, size=1))+
        theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1, size = 14))+
        theme(legend.position = "none")+
        theme(axis.text.y = element_text(angle = 0, vjust = 1, hjust=1, size = 14))+
        theme(axis.text.y = element_text(hjust = 0.4,size = 15),
              axis.title.y=element_blank(),
              axis.ticks.length.y = unit(.25, "cm"))+
        annotate("text",
                 x = 1:length(table(Strip_df$Sample)),
                 # y = aggregate(Strip_df$mut_ratio_percentage ~ Strip_df$Sample, Strip_df, median)[ , 2],
                 y = label_pos,
                 label = table(Filt_df.mut$Sample),
                 col = "black",
                 vjust = - 1, size = 5)+
        xlab("")+
        ylab("Mutation Ratio (%)")+
        ggtitle(str_c(mut," mutation off-target sites count"))+
        scale_x_discrete(drop=FALSE)+
        geom_vline(xintercept=xintercept_loc, 
                   color = "grey", size=0.5)
      
      ggsave(p,file=str_c(jitter_plot_pdf,"_Only_",fwd_mut,"_",rev_mut,".pdf"),
            height=10, width=1*length(Case_ls)+1.5,limitsize=FALSE)
      # p
      jitter_plot_merge[[length(all_mut)+i]] <- p
    }
  }
  
  # grid.arrange(grobs = jitter_plot_merge, ncol = 4) ## display plot
  ggsave(file = jitter_plot_pdf, 
         arrangeGrob(grobs = jitter_plot_merge, ncol = round(sqrt(length(jitter_plot_merge)))), 
         height = jitter_height, width = jitter_width,limitsize = FALSE)
  
  ### ######################################################################################### ###
  ###       Step3: Based on the cutoff filt df, plot the cutoff all mutation heatmap plot       ###
  ### ######################################################################################### ###
  ## Cutoff sites for mut heatmap
  # Filt_df$Sample <- factor(Filt_df$Sample, levels = unique(Filt_df$Sample))
  Filt_df$Sample <- factor(Filt_df$Sample, levels = Samples_Level)
  Cutoff_mut_type_count <- Filt_df %>% group_by(Sample,mut_type) %>% summarise(count = n())
  
  All_mut_type <- c("AA","AC","AG","AT",
                    "CA","CC","CG","CT",
                    "GA","GC","GG","GT",
                    "TA","TC","TG","TT")
  
  Case_ls <- unique(Strip_df$Sample)
  # Case_ls <- Samples_Level
  
  Add_mut_type <- list()
  for (i in 1:length(Case_ls)){
    case_name = Case_ls[i]
    case_filt <- Cutoff_mut_type_count %>% filter(Sample == case_name)
    has_mut <- unique(case_filt$mut_type)
    
    not_has_mut <- list()
    for (j in 1:length(All_mut_type)){
      if (All_mut_type[j] %in% has_mut == FALSE){
        not_has_mut[[j]] <- All_mut_type[j]
      }
    }
    
    not_has_mut_n <- as.character(unlist(not_has_mut))
    # print(case_name)
    # print(not_has_mut_n)
    
    df <- data.frame(
      Sample = rep(c(case_name),length(not_has_mut_n)),
      mut_type = not_has_mut_n,
      count = rep(c(0),length(not_has_mut_n))
    )
    
    # print(df)
    Add_mut_type[[i]] <- df
  }
  
  Add_mut_count <- bind_rows(Add_mut_type)
  
  All_mut_type_count <- bind_rows(Cutoff_mut_type_count, Add_mut_count)
  # colnames(All_mut_type_count)
  
  All_mut_type_count.F <- All_mut_type_count %>% mutate(
    From = str_split_fixed(mut_type,"",2)[,1],
    To = str_split_fixed(mut_type,"",2)[,2]
  )
  
  All_mut_type_count.F <- All_mut_type_count.F %>% add_count(Sample, wt = count) %>% 
    mutate(mut_ratio = count*100/n)
  
  RColorBrewer::display.brewer.all()
  color_list = colorRampPalette(brewer.pal(5,mut_heat_color))(30)
  color_values <- scales::rescale(mut_heat_values)
  # color_values <- scales::rescale(c(0, 6, seq(7, 15, length.out=8)))
  # color_labels <- c(0, 10, 100, 1000, 10000)
  color_labels <- mut_heat_lebels
  color_breaks <- log2(color_labels + 1)
  
  # mut_heat_values <- c(0, 6, seq(7, 15, length.out=8))
  
  # ggplot(data=All_mut_type_count.F,aes(x=From,y=To)) +
  #   geom_tile(aes(fill= mut_ratio)) +
  #   geom_text(aes(label= paste(mut_ratio,"/n","(",count,")"))) +
  #   scale_fill_gradientn(colours=color_list) + 
  #   # facet_grid(Coverage_Num ~ Mutation_Ratio + Mutation_Num) + 
  #   labs(x="From",y="To",legend = "Proportion") + 
  #   theme_bw() +
  #   theme(plot.title = element_text(hjust = 0.5))
  
  All_mut_type_count.F[is.na(All_mut_type_count.F)] <- 0
  
  # write_tsv(All_mut_type_count.F,file = "Plot_mut_heatmap.tsv")
  
  # plot_merge <- list()
  # for (i in 1:length(Case_ls)){
  #   case_name <- Case_ls[i]
  #   
  #   p <- ggplot(data=filter(All_mut_type_count.F,Sample==case_name),aes(x=From,y=To)) +
  #     geom_tile(aes(fill= log2(mut_ratio+1)),colour="#5e6472",size=0.3) +
  #     geom_text(aes(label= paste(round(mut_ratio,2),"%","\n","(",count,")"))) +
  #     scale_fill_gradientn(colours=color_list, values = color_values) + 
  #     labs(x="From",y="To",legend = "Proportion") + 
  #     theme_bw() +
  #     # theme(plot.title = element_text(hjust = 0.5))+
  #     ggtitle(str_c(case_name))
  #   
  #   plot_merge[[i]] <- p
  # }
  All_mut_type_count.F$Sample <- factor(All_mut_type_count.F$Sample, levels = Samples_Level)
  
  # colour="#5e6472"
  p <- ggplot(data=All_mut_type_count.F,aes(x=From,y=To)) +
    geom_tile(aes(fill= log2(count+1)),colour="grey",size=0.3) +
    geom_text(aes(label= paste(round(mut_ratio,2),"%","\n","(",count,")")), size = 6) +
    scale_fill_gradientn(colours=color_list, values = color_values,
                         breaks= color_breaks, labels=color_labels) + 
    facet_wrap( ~ Sample, scales = "free") +
    labs(title = "RNA level off-targets count table",x="From Base",y="To Base",fill = "Count") + 
    theme_bw() +
    theme_minimal()+
    # theme(plot.title = element_text(hjust = 0.5))+
    theme(
      plot.title = element_text(hjust = 0.5, size=20),
      axis.text=element_text(size=18),
      axis.title=element_text(size=18),
      axis.title.x=element_text(size=18),
      axis.title.y=element_text(size=18),
      strip.text.x = element_text(size = 18),
      legend.text=element_text(size=6)
    )
    
  
  # grid.arrange(grobs = plot_merge, ncol = 7) ## display plot
  ggsave(p, file = mut_heatmap_pdf,height = mut_heatmap_height, width = mut_heatmap_width)
         # arrangeGrob(grobs = plot_merge, ncol = round(sqrt(length(plot_merge)))), 
         # height = mut_heatmap_height, width = mut_heatmap_width)
}

Plot_cutoff_mut_heat_jitter_plots(pmat_path = pmat_path,file_pattern=file_pattern,
                                  case_split_pattern = case_split_pattern,
                                  mutation_combine = mut_combination,
                                  mut_number_cutoff = mut_count,
                                  cover_num_cutoff = cover_reads,
                                  max_cover_cutoff = max_cover_count,
                                  mut_ratio_cutoff = mut_ratio_cutoff,
                                  Samples_Level = Sample_levels,
                                  color_value = Colors_values,
                                  jitter_plot_pdf = output_jitter_pdf_name,
                                  jitter_height = out_jitter_height,jitter_width = out_jitter_width,
                                  mut_heatmap_pdf = output_mutheat_pdf_name,
                                  mut_heatmap_height = out_mutheat_height, mut_heatmap_width = out_mutheat_width,
                                  mut_heat_color = mut_heat_color, mut_heat_values=mut_heat_value, mut_heat_lebels = mut_heat_lebel,
                                  y_max=ylim_max,label_pos=label_pos,xintercept_loc = xintercept)





# a <- c("ABE-ABE8e_1","ABE-ABE8e_2","ABE-ABE8e_3","ABE_ABE9.2-zh430_1","ABE_ABE9.2-zh430_2","ABE_ABE9.2-zh430_3",
#        "ABE_ABE9.3-zh437_1","ABE_ABE9.3-zh437_2","ABE_ABE9.3-zh437_3","ABE_ABE9s-ABE9_1","ABE_ABE9s-ABE9_2",
#        "ABE_ABE9s-ABE9_3","ABE-nCas9_1","ABE-nCas9_2","ABE-nCas9_3")
# b <- c("#90be6d","#90be6d","#90be6d","#eaac8b","#eaac8b","#eaac8b","#5f0f40","#5f0f40","#5f0f40",
#        "#f9844a","#f9844a","#f9844a","#f8961e","#f8961e","#f8961e")
# c <- setNames(b,a)
# c
# ABE_color_values


# c(0,6,seq(7,15,length.out=8))

       