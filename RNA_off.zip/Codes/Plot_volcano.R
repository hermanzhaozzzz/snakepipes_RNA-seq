library(ggplot2)
library(ggrepel)
library(ggthemes)
library(tidyverse)

filenames <- list.files(".",pattern = ".patch")

for (i in 1:length(filenames)){
  in_file <- filenames[[i]]
  title_vs <- unlist(str_split(in_file,".patch"))[1]
  # print(title_vs)
  
  x <- read.csv(in_file,sep = "\t")
  colnames(x) <- c("test_id","gene_id","gene","locus","sample_1","sample_2","status",
                   "value_1","value_2","log2FC","test_stat","p_value","q_value","significant")
  # colnames(x)
  
  x <- filter(x, status == "OK", is.na(test_stat) == FALSE)
  
  df <- x %>%
    mutate(gene_type=if_else(        
      p_value > 0.05,"ns",if_else(          
        abs(log2FC) < 1,"ns",
        if_else(log2FC >=1,"up","down"))),
      FC=2**log2FC)
  
  
  stats <- df %>% group_by(gene_type) %>% 
    summarise(count=n())
  
  # [1] down [2] ns [3] up
  down_n <- stats$count[1]
  ns_n <- stats$count[2]
  up_n <- stats$count[3]
  
  type_sig <- c(str_c("Up: ",up_n), str_c("Down: ",down_n),str_c("NS: ",ns_n))
  counts_sig <- c("#FF0000","#00A08A","grey")
  
  cols <- setNames(counts_sig, type_sig)
  
  p <- ggplot(df %>% mutate(gene_type=case_when(
        gene_type =="up" ~ str_c("Up: ",up_n),
        gene_type =="down" ~ str_c("Down: ",down_n),
        gene_type =="ns" ~ str_c("NS: ",ns_n))),aes(log2FC,-log10(p_value))) + 
        geom_point(aes(color=gene_type,size=abs(log2FC)))+
        geom_hline(yintercept = -log10(0.05),linetype ="dashed") +  # 添加水平线
        geom_vline(xintercept = c(-1,1),linetype = "dashed")+       # 添加垂直线
        # geom_label_repel(data=df %>%  # 展示自己所需要的基因名称
        #                    filter(abs(log2FC) >= 1,p_value < 0.05),
        #                  aes(label=gene_id),max.overlaps = Inf,verbose = TRUE,size=3)+
        scale_color_manual(values = cols) + 
        scale_size(range=c(0.1,3))+
        guides(size="none")+
        scale_x_continuous(breaks=c(seq(-10,10,2)),limits = c(-10,10))+
        theme(panel.grid.major=element_blank(), # 移除主网格
              panel.grid.minor=element_blank(), # 移除次网格线
              panel.background = element_blank(), # 设置背景为空
              plot.title = element_text(size = 20),
              axis.title.x=element_text(color="black",size=14,margin = margin(t = 5)),
              axis.title.y=element_text(color="black",size=14,margin = margin(t = 5)),
              axis.text.x=element_text(color="black",margin = margin(t = 5),size = 12), # 设置X轴文本颜色
              axis.text.y=element_text(color="black",margin = margin(r = 5),size = 12), # 设置y轴文本颜色
              panel.border = element_rect(linetype = "solid",fill = NA), # 定义边框线条类型
              plot.margin=unit(c(0.5,0.5,0.5,0.5),units=,"cm"),
              legend.title = element_blank(),
              legend.key=element_blank(),   # 图例键为空
              legend.text = element_text(color="black",size=10), # 定义图例文本
              legend.spacing.x=unit(0,'cm'), # 定义文本书平距离
              legend.background=element_blank(), # 设置背景为空
              legend.box.background=element_rect(colour = "black"), # 图例绘制边框
              legend.box.margin = margin(1,1,1,1),
              legend.position = c(0,1),legend.justification = c(0,1))+
        ggtitle(title_vs) +
        xlab("-Log2(Fold Change)") + ylab("-Log210(Pvalue)")
  ggsave(p,filename = str_c(title_vs,"_volcano_plot.pdf"),
         height = 8, width = 10)
}






# 
# 
# 
# x <- read.csv("LELmax-P10b_vs_LELvector.patch",sep = "\t")
# colnames(x) <- c("test_id","gene_id","gene","locus","sample_1","sample_2","status",
#                  "value_1","value_2","log2FC","test_stat","p_value","q_value","significant")
# colnames(x)
# 
# x <- filter(x, status == "OK", is.na(test_stat) == FALSE)
# 
# 
# df <- x %>%
#   mutate(gene_type=if_else(        
#     p_value > 0.05,"ns",if_else(          
#       abs(log2FC) < 1,"ns",
#       if_else(log2FC >=1,"up","down"))),
#     FC=2**log2FC)
# 
# 
# stats <- df %>% group_by(gene_type) %>% 
#   summarise(count=n())
# 
# # [1] down [2] ns [3] up
# stats$count[1]
# 
# cols <- c("up [10]"="#FF0000","down [27]"="#00A08A","ns [16169]"="grey")
# 
# ggplot(df %>% mutate(gene_type=case_when(
#   gene_type =="up" ~ "up [10]",
#   gene_type =="down" ~ "down [27]",
#   gene_type =="ns" ~ "ns [16169]")),aes(log2FC,-log10(p_value))) + 
#   geom_point(aes(color=gene_type,size=abs(log2FC)))+
#   geom_hline(yintercept = -log10(0.05),linetype ="dashed") +  # 添加水平线
#   geom_vline(xintercept = c(-1,1),linetype = "dashed")+       # 添加垂直线
#   geom_label_repel(data=df %>%  # 展示自己所需要的基因名称
#                      filter(abs(log2FC) >= 1,p_value < 0.05),
#                    aes(label=gene_id),max.overlaps = Inf,verbose = TRUE,size=3)+
#   scale_color_manual(values = cols) + 
#   scale_size(range=c(0.1,3))+
#   guides(size="none")+
#   scale_x_continuous(breaks=c(seq(-10,10,2)),limits = c(-10,10))+
#   theme(panel.grid.major=element_blank(), # 移除主网格
#         panel.grid.minor=element_blank(), # 移除次网格线
#         panel.background = element_blank(), # 设置背景为空
#         plot.title = element_text(size = 20),
#         axis.title.x=element_text(color="black",size=14,margin = margin(t = 5)),
#         axis.title.y=element_text(color="black",size=14,margin = margin(t = 5)),
#         axis.text.x=element_text(color="black",margin = margin(t = 5),size = 12), # 设置X轴文本颜色
#         axis.text.y=element_text(color="black",margin = margin(r = 5),size = 12), # 设置y轴文本颜色
#         panel.border = element_rect(linetype = "solid",fill = NA), # 定义边框线条类型
#         plot.margin=unit(c(0.5,0.5,0.5,0.5),units=,"cm"),
#         legend.title = element_blank(),
#         legend.key=element_blank(),   # 图例键为空
#         legend.text = element_text(color="black",size=10), # 定义图例文本
#         legend.spacing.x=unit(0,'cm'), # 定义文本书平距离
#         legend.background=element_blank(), # 设置
#         legend.box.background=element_rect(colour = "black"), # 图例绘制边框
#         legend.box.margin = margin(1,1,1,1),
#         legend.position = c(0,1),legend.justification = c(0,1))+
#   ggtitle("Plot of length by dose") +
#   xlab("-Log2(Fold Change") + ylab("-Log210(Pvalue)")
