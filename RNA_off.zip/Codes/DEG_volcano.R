library(tidyverse)
library(DESeq2)

rm(list = ls())

### Read raw_count file and sample table ###
file = "/Volumes/mac_data/02.Output_Process/Yilab-03.RNA_edit-TadA-project/05.20220130_v3_plus_RNA_TadA_RNA_Seq/03.FeatureCount/Feature_filt_reads.count"
condition = "/Volumes/mac_data/02.Output_Process/Yilab-03.RNA_edit-TadA-project/05.20220130_v3_plus_RNA_TadA_RNA_Seq/03.FeatureCount/Sample_condition.txt"

raw_count <- read.table(file,sep = "\t",header = T,stringsAsFactors = F, row.names = 1)

raw_count.filt <- raw_count[rowSums(raw_count) >= 20 & apply(raw_count, 1, function(x){all(x)>0}),]

colnames(raw_count.filt) <- sub("_Aligned_sort_MarkDup_rmdup_Q20_FiltClip.bam", "", colnames(raw_count.filt))

condition_table <- read.table(condition,sep = "\t",header = T, stringsAsFactors = F, row.names = 1)

### DESeq2 analysis ###
deseq2 <- DESeqDataSetFromMatrix(countData = raw_count.filt, colData = condition_table, design = ~Condition)
dds <- DESeq(deseq2)


