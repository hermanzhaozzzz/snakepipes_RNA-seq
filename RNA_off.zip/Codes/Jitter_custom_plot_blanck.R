library(tidyverse)
library(ggplot2)

args <- commandArgs(trailingOnly = TRUE)

pmat_file_path <- args[1]
file_pattern <- as.character(args[2])
sample_pattern <- as.character(args[3])
mut_count_cutoff <- as.integer(args[4])
cover_count_cutoff <- as.integer(args[5])
mut_ratio_cutoff <- as.double(args[6])
FDR_cutoff <- as.numeric(args[7])
fwd_mut <- as.character(args[8])
rev_mut <- as.character(args[9])
samples <- as.character(unlist(str_split(args[10],",")))
colors <- as.character(str_c("#",unlist(str_split(args[11],","))))
xintercept <- as.numeric(unlist(str_split(args[12],",")))
out_pdf <- args[13]
pdf_height <- as.integer(args[14])
pdf_width <- as.integer(args[15])
ylim_max <- as.numeric(args[16])
label_pos <- as.numeric(args[17])


# print(samples)
# print(colors)
# print(xintercept)


Jitter_pmat_plot <- function(pmat_path,file_pattern="pmat",case_pattern="_Aligned",
                             mut_count,cover_count,mut_ratio,fwd_mut,
                             rev_mut,samples_level,samples_color,xintercept_loc=c(0),
                             out_pdf_file,out_pdf_height=4,out_pdf_width=12,
                             y_max=120,label_pos=105){
    
#   col_type_info = cols(
#       X1 = col_character(),
#       X2 = col_double(),
#       X3 = col_double(),
#       X4 = col_character(),
#       X5 = col_double(),
#       X6 = col_double(),
#       X7 = col_double(),
#       X8 = col_double(),
#       X9 = col_character(),
#       X10 = col_character(),
#       X11 = col_character(),
#       X12 = col_double(),
#       X13 = col_double(),
#       X14 = col_double(),
#       X15 = col_double(),
#       X16 = col_double(),
#       X17 = col_double()
#   )
    
  pmat_path = pmat_path
  cols <- c("chr","start","end","site_idx",
            "A_count","G_count","C_count","T_count",
            "mut_type","From","To","ref_num","Mut_num","Cover_num","raw_mut_ratio","pvalue","qvalue")
  
  Merge_ls <- list()
  filenames <- list.files(pmat_path, pattern=str_c("*.",file_pattern), full.names=TRUE)
    
#   print(filenames)
    
  for (i in 1:length(filenames)){
    tmp <- str_split(filenames[[i]],"/")[[1]]
    file <- tmp[length(tmp)]
    case <- str_split(file, case_pattern)[[1]][1] ### pattern for split out the samples name ###
    
    # print(case)
    df <- read.table(filenames[[i]], sep="\t", col.names = cols)
    
    if (dim(df)[1] == 0){
      df <- data.frame("chr",1,100,"site_idx",
                       0,0,0,0,
                       "NN","N","N",0,0,0,0,1,1)
      colnames(df) <- cols
    }else{
      df <- df
    }
      
    df[, c(16,17)] <- sapply(df[, c(16,17)], as.numeric)
    df[, c(10,11)] <- sapply(df[, c(10,11)], as.character)
      
    df_f <- mutate(df, mut_ratio = raw_mut_ratio*100, Sample = case)
    
    Merge_ls[[i]] <- df_f
  }
  # print(Merge_ls[2])
  
  Strip_df <- bind_rows(Merge_ls)
  # Strip_df$Sample <- factor(Strip_df$Sample, levels = unique(Strip_df$Sample))
  # Strip_df$Sample <- factor(Strip_df$Sample, levels = Samples_Level)
  
  ### ######################################################################################### ###
  ### Step2: Set the cutoffs: Mut_number, Cover_number, MUt_ratio for filt sites and jitterplot ###
  ### ######################################################################################### ###
  mut_cutoff = mut_count
  cover_cutoff = cover_count
  ratio_cutoff = mut_ratio
  
  Filt_df <- Strip_df %>% filter(Mut_num >= mut_cutoff &
                                   Cover_num >= cover_cutoff &
                                   mut_ratio >= ratio_cutoff &
                                   qvalue <= FDR_cutoff &
                                   raw_mut_ratio != 1 &
                                   mut_ratio <= 95)
  
  Filt_df.mut <- Filt_df %>% filter(mut_type == fwd_mut | mut_type == rev_mut)
  # Filt_df.mut$Sample <- factor(Filt_df.mut$Sample, levels = unique(Strip_df$Sample))
  Samples_Level <- samples_level
  color_value <- samples_color
  
  Filt_df.mut$Sample <- factor(Filt_df.mut$Sample, levels = Samples_Level)
  
  Case_ls <- unique(Strip_df$Sample)
  
  p <- ggplot(Filt_df.mut,aes(x=Sample,y=mut_ratio,color=Sample,alpha=Sample))+
    geom_jitter(size=1,stroke=0)+
    # scale_color_brewer(palette="Set3")+
    # scale_fill_gradient2(low = "#264653", mid = "#e9c46a",high = "#e76f51", na.value = NA)+
    # scale_color_manual(values = (colorRampPalette(brewer.pal(11,"Spectral"))(length(Case_ls))))+
    scale_color_manual(values = color_value, drop=FALSE)+
    scale_alpha_manual(values = rep(c(0.8),each=length(Case_ls)))+
    scale_y_continuous(limits = c(0,y_max),breaks=seq(0,y_max,20))+
    # theme(panel.background = element_rect(fill = "white", colour = "black", size = 0.5))+
    theme_bw()+
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.border = element_rect(colour = "black", fill=NA, size=1))+
    theme(axis.title.x=element_blank(),
#           axis.text.x = element_text(angle = 45, vjust=0.85, hjust=0.9, size=10),
          axis.text.x =element_blank())+
#           axis.ticks.x=element_blank())+
    theme(legend.position = "none")+
    theme(axis.text.y = element_text(angle = 0, vjust = 1, hjust=1, size = 14))+
    theme(axis.text.y = element_text(hjust = 0.4,size = 15),
          axis.title.y=element_blank(),
          axis.ticks.length.y = unit(.25, "cm"))+
    annotate("text",
             x = 1:length(table(Strip_df$Sample)),
             # y = aggregate(Strip_df$mut_ratio_percentage ~ Strip_df$Sample, Strip_df, median)[ , 2],
             y = label_pos,
             label = table(Filt_df.mut$Sample),
             col = "black",
             vjust = - 1, size = 5)+
    # xlab("")+
    # ylab("Mutation Ratio (%)")+
    # ggtitle(str_c("AG-TC mutation off-target sites count"))+
    scale_x_discrete(drop=FALSE)+
    geom_vline(xintercept=xintercept_loc, 
               color = "grey", size=0.5)
  
  ggsave(p, filename = out_pdf_file,
         height = out_pdf_height, width = out_pdf_width, limitsize = FALSE)
}


Jitter_pmat_plot(pmat_path = pmat_file_path, file_pattern = file_pattern,
                 case_pattern = sample_pattern, mut_count = mut_count_cutoff,
                 cover_count = cover_count_cutoff, mut_ratio = mut_ratio_cutoff,
                 fwd_mut = fwd_mut, rev_mut = rev_mut, samples_level = samples,
                 samples_color = colors, xintercept_loc = xintercept,
                 out_pdf_file = out_pdf, out_pdf_height = pdf_height, out_pdf_width = pdf_width,
                 y_max=ylim_max,label_pos=label_pos)

