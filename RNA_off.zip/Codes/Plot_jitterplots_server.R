library(tidyverse)
library(RColorBrewer)
library(wesanderson)
library(forcats)

### pass variables from shell ###
args <- commandArgs(trailingOnly = TRUE)
pmat_path <- args[1]
fwd_mut <- as.character(args[2])
rev_mut <- as.character(args[3])
mut_count <- as.double(args[4])
cover_reads <- as.double(args[5])
mut_ratio_cutoff <- as.double(args[6])
output_path <- args[7]
output_pdf_name <- args[8]
Sample_levels <- as.character(unlist(str_split(args[9],",")))
Colors_values <- as.character(str_c("#",unlist(str_split(args[10],","))))
ylabel <- args[11]
out_pdf_height <- as.integer(args[12])
out_pdf_width <- as.integer(args[13])

dir.create(output_path)

cols <- c("chr_name","chr_index_s","chr_index_e","site_index","A","G","C","T",
          "mut_type","ref_base","mut_base","ref_num","mut_num","cover_num","mut_ratio")

Merge_ls <- list()
filenames <- list.files(pmat_path, pattern="*.pmat", full.names=TRUE)
for (i in 1:length(filenames)){
  tmp <- str_split(filenames[[i]],"/")[[1]]
  file <- tmp[length(tmp)]
  case <- str_split(file, "_")[[1]][1]
  
  # print(case)
  df <- read.table(filenames[[i]], sep="\t")
  colnames(df) <- cols
  df <- df %>% mutate(Sample = case, mut_ratio_percentage = mut_ratio*100)
  df_f <- filter(df, mut_num>=mut_count & cover_num >= cover_reads & 
                   mut_ratio_percentage>=mut_ratio_cutoff & (mut_type == fwd_mut | mut_type == rev_mut))
  df_f <- df_f %>% mutate(IDs = str_c(case,site_index,sep="__"), .after=chr_index_e)
  df_f <- df_f %>% mutate(bed_col5=".", .after=IDs)
  df_f <- df_f %>% mutate(Orientation = ifelse(mut_type==fwd_mut,"+","-"), .after=bed_col5)
  
  df_fl <- filter(df, mut_num>=mut_count & cover_num >= cover_reads & mut_ratio_percentage>=mut_ratio_cutoff &
                    (mut_type != fwd_mut & mut_type != rev_mut))
  
  write.table(df_f,file = str_c(output_path,"/",case,"_filter.txt"),
                                quote = F,sep = "\t",row.names = F,col.names = F)
  write.table(df_fl,file = str_c(output_path,"/",case,"_filter_other_mut.txt"),
              quote = F,sep = "\t",row.names = F,col.names = F)
  
  if (nrow(df_f) != 0){
    Merge_ls[[i]] <- df_f
  }else{
    t <- data.frame("chr_name"="chr6","chr_index_s"=85677958,"chr_index_e"=85677958,"IDs"="fake_chr6_666_888","bed_col5"=".",
                    "Orientation"="-","site_index"="fake_chr6_none","A"=0,"G"=0,"C"=0,"T"=0,
                    "mut_type"="None","ref_base"="None","mut_base"="None","ref_num"=0,"mut_num"=0,
                    "cover_num"=0,"mut_ratio"=0,"Sample"=case,"mut_ratio_percentage"=0)
    df_f <- rbind(df_f,t)
    
    # print(df_f)
    Merge_ls[[i]] <- df_f
  }
  # Merge_ls[[i]] <- df_f
}

Strip_df <- bind_rows(Merge_ls)

# colnames(Strip_df)
# Strip_df$Sample
# unique(Strip_df$Sample)

Strip_df$Sample <- factor(Strip_df$Sample,levels = Sample_levels)
# levels(Strip_df$Sample)
color_value = Colors_values
#fct_infreq(Sample) order by count decrease
p <- ggplot(Strip_df,aes(x=Sample,y=mut_ratio_percentage,color=Sample,alpha=Sample))+
  geom_jitter()+
  # scale_color_brewer(palette="Set3")+
  # scale_fill_gradient2(low = "#264653", mid = "#e9c46a",high = "#e76f51", na.value = NA)+
  scale_color_manual(values = color_value)+
  scale_alpha_manual(values = rep(c(0.6),each=length(filenames)))+
  theme(panel.background = element_rect(fill = "white", colour = "black", size = 2))+
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1, size = 12))+
  annotate("text",
           x = 1:length(table(Strip_df$Sample)),
           # y = aggregate(Strip_df$mut_ratio_percentage ~ Strip_df$Sample, Strip_df, median)[ , 2],
           y = 101,
           label = table(Strip_df$Sample),
           col = "black",
           vjust = - 1, size = 5)+
  xlab("")+
  ylab(ylabel)

ggsave(p, filename = output_pdf_name, height = out_pdf_height, width = out_pdf_width)

