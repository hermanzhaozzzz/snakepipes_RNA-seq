library(tidyverse)
library(VennDiagram)
library(ggplotify)

args <- commandArgs(trailingOnly = TRUE)
pmat_file1_raw <- args[1]
pmat_file2_raw <- args[2]
split_pattern <- args[3]
outpdf <- args[4]
out_width <- as.integer(args[5])
out_height <- as.integer(args[6])

# pmat_file1_raw <- "./aaa/./REPAIRv2_TAG-repoter_M3C15R0_AG_TC_filter.txt"
# pmat_file1_tmp <- unlist(str_split(pmat_file1_raw,"/"))
# print(pmat_file1_tmp)

if (grepl("/",pmat_file1_raw)){
  pmat_file1_tmp <- unlist(str_split(pmat_file1_raw,"/"))
  pmat_file1 <- unlist(str_split(pmat_file1_tmp[length(pmat_file1_tmp)],split_pattern))[1]
}else{
  pmat_file1 <- unlist(str_split(pmat_file1_raw,split_pattern))[1]
}
if (grepl("/",pmat_file2_raw)){
  pmat_file2_tmp <- unlist(str_split(pmat_file2_raw,"/"))
  pmat_file2 <- unlist(str_split(pmat_file2_tmp[length(pmat_file2_tmp)],split_pattern))[1]
}else{
  pmat_file2 <- unlist(str_split(pmat_file1_raw,split_pattern))[1]
}

# if(file.info(pmat_file1_raw)$size == 0){
#     print("yes")   
# }else{
#     print("no")
# }

if (file.info(pmat_file1_raw)$size == 0){
    file1 <- data.frame(matrix(ncol = 22, nrow = 0))
    colnames(file1) <- rep(str_c("V",1:22))
}else{
    file1 <- read.table(pmat_file1_raw,sep = "\t")
}

if (file.info(pmat_file2_raw)$size == 0){
    file2 <- data.frame(matrix(ncol = 22, nrow = 0))
    colnames(file2) <- rep(str_c("V",1:22))
}else{
    file2 <- read.table(pmat_file2_raw,sep = "\t")
}

if (file.info(pmat_file1_raw)$size == 0 && file.info(pmat_file2_raw)$size == 0){
    file1 <- data.frame(matrix(ncol = 22, nrow = 0))
    file2 <- data.frame(matrix(ncol = 22, nrow = 0))
    
    colnames(file1) <- rep(str_c("V",1:22))
    colnames(file2) <- rep(str_c("V",1:22))
    
    file1[nrow(file1) + 1,] = colnames(file1)
    file2[nrow(file2) + 1,] = colnames(file2)
}



overlap <- intersect(file1$V7, file2$V7)
file1.self <- setdiff(file1$V7, file2$V7)
file2.self <- setdiff(file2$V7, file1$V7)

file1_name <- pmat_file1
file2_name <- pmat_file2
# length(Repairv2)
# length(Repairv2_NT)
# length(overlap)
# length(Repairv2.self)
# length(Repairv2_NT.self)


pdf(
  file = outpdf,
  height = out_height, 
  width = out_width)

draw.pairwise.venn(
  area1 = length(file1$V7),
  area2 = length(file2$V7),
  cross.area = length(overlap),
  category = c(file1_name, file2_name),
  fill = c("#dcdcd7", "#e3cfc1"),
  lty = "blank",
  cex = 2,
  cat.cex = 2,
  cat.pos = c(180, 170)
)

dev.off()
# 
# venn <- as.ggplot(venn.plot)
# ggsave(venn, filename = outpdf, width = out_width, height = out_height)
