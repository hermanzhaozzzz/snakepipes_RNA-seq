import argparse

# ============= main part ==========>>>>>>>>>>>>>>>>>>>>>>
if __name__ == '__main__':
	parser = argparse.ArgumentParser(description="Extract random mutation from bmat file")
	parser.add_argument("-i", "--input_bmat", help="input the bmat file", required=True)
	parser.add_argument('-o', '--output_mut_info', help="output the extract mutation info file", required=True)
	parser.add_argument('-fwd_f', '--fwd_from_base', help="Forward mutation from base", required=True)
	parser.add_argument('-fwd_t', '--fwd_to_base', help='Forward mutation to base', required=True)
	parser.add_argument('-rev_f', '--rev_from_base', help="Reverse mutation from base", required=True)
	parser.add_argument('-rev_t', '--rev_to_base', help='Reverse mutation to base', required=True)
	parser.add_argument('-mut_count', '--Mut_count_cutoff', help='Mutation count cutoff', required=True)

	ARGS = parser.parse_args()

	### ==== identify params and load files =====###
	input_b = ARGS.input_bmat
	output_b = ARGS.output_mut_info
	Fwd_From = ARGS.fwd_from_base
	Fwd_To = ARGS.fwd_to_base
	Rev_From = ARGS.rev_from_base
	Rev_To = ARGS.rev_to_base
	Mut_count = ARGS.Mut_count_cutoff

	### =======================================>>>>>>
	### ============ Main analysis part ========= ###
	### =======================================>>>>>>

	out = open(output_b, "w")
	cols = ["chr_name", "chr_index", "ref_base", "A", "G", "C", "T",
			"del_count", "insert_count", "ambiguous_count",
			"deletion", "insertion", "ambiguous", "mut_num"]
	out.write("\t".join(cols) + "\n")

	with open(input_b) as f:
		for lines in f:
			line = lines.strip().split("\t")
			chr_n, chr_index, ref_base = line[0], line[1], line[2]
			mut = {"A":line[3],"G":line[4],"C":line[5],"T":line[6]}
			mut_num = line[-1]

			if chr_n != "chr_name":
				if ref_base == Fwd_From:
					if int(mut[Fwd_To]) >= int(Mut_count):
						out.write(lines.strip() + "\n")
				elif ref_base == Rev_From:
					if int(mut[Rev_To]) >= int(Mut_count):
						out.write(lines.strip() + "\n")
	out.close()