library(tidyverse)
library(ggplot2)
library(ggseqlogo)

### pass variables from shell ###
args <- commandArgs(trailingOnly = TRUE)

cs1 = make_col_scheme(chars=c('A', 'T', 'C', 'G', "N", "U"), 
                      cols=c('#2A9D8F', '#E63946', '#457B9D', '#DDA15E', "purple", '#E63946'))

Plot_motifs <- function(in_seqs_path,file_patter,
                        out_pdf_name,plot_ncol,
                        plot_height,plot_width){
  file_path <- in_seqs_path
  Path_seqs <- list.files(file_path,pattern = file_patter)
  file_merge <- list()
  for (file_name in Path_seqs){
    
    show_name = str_split(file_name,".txt")[[1]][1]
    show_name <- str_replace(show_name, "seqs", "sites")
    
    each_file <- read.table(paste(file_path,file_name,sep="/"))
    each_file_f <- as.character(each_file$V1)
    
    show_name <- str_c(show_name," (",nrow(each_file),")")
    
    file_merge[[as.character(show_name)]] <- each_file_f
  }
  
  plot <- ggseqlogo(file_merge, ncol = plot_ncol, method = "prob",col_scheme=cs1)+
    theme_bw()+theme_classic()
  # plot <- ggseqlogo(file_merge, ncol = plot_ncol, method="prob")+theme_bw()+theme_classic()
  # plot <- ggseqlogo(file_merge, ncol = plot_ncol)
  
  ggsave(plot, filename = out_pdf_name, height = plot_height, width = plot_width)
}


input_seqs_path_t <-  args[1] ### input_seqs_path should not cantain "/" at last
if (substring(input_seqs_path_t,nchar(input_seqs_path_t)) == "/"){
  input_seqs_path <- substring(input_seqs_path_t,1,nchar(input_seqs_path_t)-1)
}else{
  input_seqs_path <- input_seqs_path_t
}

plot_cols <- as.integer(args[2])
### plot left and right extend RNA sequence motif ###
out_extend_pdf_name <- args[3]
extend_pdf_height <- as.integer(args[4])
extend_pdf_width <- as.integer(args[5])
Plot_motifs(in_seqs_path = input_seqs_path,file_patter = "*Extend*",
            out_pdf_name = out_extend_pdf_name, plot_ncol = plot_cols, 
            plot_height = extend_pdf_height, plot_width = extend_pdf_width)

### plot codon RNA sequence motif ###
out_codon_pdf_name <- args[6]
codon_pdf_height <- as.integer(args[7])
codon_pdf_width <- as.integer(args[8])
Plot_motifs(in_seqs_path = input_seqs_path,file_patter = "*codon_RNA*",
            out_pdf_name = out_codon_pdf_name, plot_ncol = plot_cols, 
            plot_height = codon_pdf_height, plot_width = codon_pdf_width)

