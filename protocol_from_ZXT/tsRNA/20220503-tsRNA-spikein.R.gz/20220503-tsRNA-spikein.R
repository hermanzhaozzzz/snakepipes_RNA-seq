rm(list = ls())
library(BRGenomics)
library(Repitools)
library(tidyverse)
# build demo data ---------------------------------------------------------


gr1_rep1 <- GRanges(seqnames = c("chr1", "chr2", "spikechr1", "spikechr2"),
                    ranges = IRanges(start = 1:4, width = 1),
                    strand = "+")
gr2_rep2 <- gr2_rep1 <- gr1_rep2 <- gr1_rep1

score(gr1_rep1) <- c(1, 1, 1, 1) # 2 exp + 2 spike = 4 total
score(gr2_rep1) <- c(2, 2, 1, 1) # 4 exp + 2 spike = 6 total
score(gr1_rep2) <- c(1, 1, 2, 1) # 2 exp + 3 spike = 5 total
score(gr2_rep2) <- c(4, 4, 2, 2) # 8 exp + 4 spike = 12 total

grl <- list(gr1_rep1, gr2_rep1,
            gr1_rep2, gr2_rep2)

names(grl) <- c("gr1_rep1", "gr2_rep1",
                "gr1_rep2", "gr2_rep2")
grl


# getSpikeincount ---------------------------------------------------------
##会统计这个里面的  total_reads exp_reads spike_reads的数目

getSpikeInCounts(grl, si_pattern = "spike", ncores = 1)



##将 spikein 移除
removeSpikeInReads(grl[1:2], si_pattern = "spike", ncores = 1)


getSpikeInNFs(grl, si_pattern = "spike", ctrl_pattern = "gr1", ncores = 1)

spikeInNormGRanges(grl, si_pattern = "spike", ctrl_pattern = "gr1", ncores = 1)


# true data ---------------------------------------------------------------
# setwd("/Users/xiaotingzhang/Documents/YiLab/data/140_Proj_tsRNASeq/25-tsRNA-rawdata-20220501")
setwd("/Users/zhaohuanan/Desktop/ZXTing")
title <- c("PUS10_R1","PUS10_R2","PUS1_R1","PUS1_R2","PUS3_R1","PUS3_R2",
           "PUS7_R1","PUS7_R2","PUS7L_R1","PUS7L_R2","PUSL1_R1","PUSL1_R2",
           "RD1_R1","RD1_R2","RD2_R1","RD2_R2","RD3_R1","RD3_R2","TRUB1_R1",
           "TRUB1_R2","WT_R1","WT_R2")
tRNA <- read.csv("20220428_tsRNA_15_50_tidy_readsnumber.tRNA.csv",header=F,row.names = 1)

names(tRNA) <- title

tRNA$id <- rownames(tRNA)
tRNA <- melt(tRNA,id.vars="id")

spikein <- read.csv("20220428_tsRNA_15_50_tidy_readsnumber.spikein.csv",header=F)
names(spikein) <- c("id",title)
head(spikein)
spikein <- dplyr::filter(spikein,(id == "spikein_34nt_1-34" )|(id == "spikein_50nt_1-50" ))
head(spikein)
rownames(spikein) <- spikein$id
# spikein <- spikein[,-1]
head(spikein)


# reshapae -----------------------------------------------------------------
library(reshape2)

spikein <- melt(spikein,id.vars="id")

data <- rbind(spikein,tRNA)
names(data) <- c("chr","sample","score")
data$score = data$score +1

data_WT_R1 <- dplyr::filter(data,sample=="WT_R1")
data_WT_R1 <- GRanges(seqnames = data_WT_R1$chr,
                      ranges = IRanges(start = 1:136093, width = 1),
                      strand = "+",score=data_WT_R1$score)


data_PUS10_R1 <- dplyr::filter(data,sample=="PUS10_R1")
data_PUS10_R1 <- GRanges(seqnames = data_PUS10_R1$chr,
                         ranges = IRanges(start = 1:136093, width = 1),
                         strand = "+",score=data_PUS10_R1$score)

data_PUS1_R1 <- dplyr::filter(data,sample=="PUS1_R1")
data_PUS1_R1 <- GRanges(seqnames = data_PUS1_R1$chr,
                        ranges = IRanges(start = 1:136093, width = 1),
                        strand = "+",score=data_PUS1_R1$score)


data_PUS3_R1 <- dplyr::filter(data,sample=="PUS3_R1")
data_PUS3_R1 <- GRanges(seqnames = data_PUS3_R1$chr,
                        ranges = IRanges(start = 1:136093, width = 1),
                        strand = "+",score=data_PUS3_R1$score)


data_PUS7_R1 <- dplyr::filter(data,sample=="PUS7_R1")
data_PUS7_R1 <- GRanges(seqnames = data_PUS7_R1$chr,
                        ranges = IRanges(start = 1:136093, width = 1),
                        strand = "+",score=data_PUS7_R1$score)


data_PUS7L_R1 <- dplyr::filter(data,sample=="PUS7L_R1")
data_PUS7L_R1 <- GRanges(seqnames = data_PUS7L_R1$chr,
                         ranges = IRanges(start = 1:136093, width = 1),
                         strand = "+",score=data_PUS7L_R1$score)

data_PUSL1_R1 <- dplyr::filter(data,sample=="PUSL1_R1")
data_PUSL1_R1 <- GRanges(seqnames = data_PUSL1_R1$chr,
                         ranges = IRanges(start = 1:136093, width = 1),
                         strand = "+",score=data_PUSL1_R1$score)

data_RD1_R1 <- dplyr::filter(data,sample=="RD1_R1")
data_RD1_R1 <- GRanges(seqnames = data_RD1_R1$chr,
                       ranges = IRanges(start = 1:136093, width = 1),
                       strand = "+",score=data_RD1_R1$score)
data_RD2_R1 <- dplyr::filter(data,sample=="RD2_R1")
data_RD2_R1 <- GRanges(seqnames = data_RD2_R1$chr,
                       ranges = IRanges(start = 1:136093, width = 1),
                       strand = "+",score=data_RD2_R1$score)

data_RD3_R1 <- dplyr::filter(data,sample=="RD3_R1")
data_RD3_R1 <- GRanges(seqnames = data_RD3_R1$chr,
                       ranges = IRanges(start = 1:136093, width = 1),
                       strand = "+",score=data_RD3_R1$score)

data_TRUB1_R1 <- dplyr::filter(data,sample=="TRUB1_R1")
data_TRUB1_R1 <- GRanges(seqnames = data_TRUB1_R1$chr,
                         ranges = IRanges(start = 1:136093, width = 1),
                         strand = "+",score=data_TRUB1_R1$score)



data_WT_R2 <- dplyr::filter(data,sample=="WT_R2")
data_WT_R2 <- GRanges(seqnames = data_WT_R2$chr,
                      ranges = IRanges(start = 1:136093, width = 1),
                      strand = "+",score=data_WT_R2$score)


data_PUS10_R2 <- dplyr::filter(data,sample=="PUS10_R2")
data_PUS10_R2 <- GRanges(seqnames = data_PUS10_R2$chr,
                         ranges = IRanges(start = 1:136093, width = 1),
                         strand = "+",score=data_PUS10_R2$score)

data_PUS1_R2 <- dplyr::filter(data,sample=="PUS1_R2")
data_PUS1_R2 <- GRanges(seqnames = data_PUS1_R2$chr,
                        ranges = IRanges(start = 1:136093, width = 1),
                        strand = "+",score=data_PUS1_R2$score)


data_PUS3_R2 <- dplyr::filter(data,sample=="PUS3_R2")
data_PUS3_R2 <- GRanges(seqnames = data_PUS3_R2$chr,
                        ranges = IRanges(start = 1:136093, width = 1),
                        strand = "+",score=data_PUS3_R2$score)


data_PUS7_R2 <- dplyr::filter(data,sample=="PUS7_R2")
data_PUS7_R2 <- GRanges(seqnames = data_PUS7_R2$chr,
                        ranges = IRanges(start = 1:136093, width = 1),
                        strand = "+",score=data_PUS7_R2$score)


data_PUS7L_R2 <- dplyr::filter(data,sample=="PUS7L_R2")
data_PUS7L_R2 <- GRanges(seqnames = data_PUS7L_R2$chr,
                         ranges = IRanges(start = 1:136093, width = 1),
                         strand = "+",score=data_PUS7L_R2$score)

data_PUSL1_R2 <- dplyr::filter(data,sample=="PUSL1_R2")
data_PUSL1_R2 <- GRanges(seqnames = data_PUSL1_R2$chr,
                         ranges = IRanges(start = 1:136093, width = 1),
                         strand = "+",score=data_PUSL1_R2$score)

data_RD1_R2 <- dplyr::filter(data,sample=="RD1_R2")
data_RD1_R2 <- GRanges(seqnames = data_RD1_R2$chr,
                       ranges = IRanges(start = 1:136093, width = 1),
                       strand = "+",score=data_RD1_R2$score)
data_RD2_R2 <- dplyr::filter(data,sample=="RD2_R2")
data_RD2_R2 <- GRanges(seqnames = data_RD2_R2$chr,
                       ranges = IRanges(start = 1:136093, width = 1),
                       strand = "+",score=data_RD2_R2$score)

data_RD3_R2 <- dplyr::filter(data,sample=="RD3_R2")
data_RD3_R2 <- GRanges(seqnames = data_RD3_R2$chr,
                       ranges = IRanges(start = 1:136093, width = 1),
                       strand = "+",score=data_RD3_R2$score)

data_TRUB1_R2 <- dplyr::filter(data,sample=="TRUB1_R2")
data_TRUB1_R2 <- GRanges(seqnames = data_TRUB1_R2$chr,
                         ranges = IRanges(start = 1:136093, width = 1),
                         strand = "+",score=data_TRUB1_R2$score)







data_gr <- list(data_WT_R1,data_PUS10_R1,data_PUS1_R1,data_PUS3_R1,data_PUS7_R1,data_PUS7L_R1,data_PUSL1_R1,data_RD1_R1,data_RD2_R1,data_RD3_R1,data_TRUB1_R1,
                data_WT_R2,data_PUS10_R2,data_PUS1_R2,data_PUS3_R2,data_PUS7_R2,data_PUS7L_R2,data_PUSL1_R2,data_RD1_R2,data_RD2_R2,data_RD3_R2,data_TRUB1_R2)

names(data_gr) <- c("data_WT_rep1","data_PUS10_rep1","data_PUS1_rep1","data_PUS3_rep1","data_PUS7_rep1","data_PUS7L_rep1","data_PUSL1_rep1","data_RD1_rep1","data_RD2_rep1","data_RD3_rep1","data_TRUB1_rep1",
                    "data_WT_rep2","data_PUS10_rep2","data_PUS1_rep2","data_PUS3_rep2","data_PUS7_rep2","data_PUS7L_rep2","data_PUSL1_rep2","data_RD1_rep2","data_RD2_rep2","data_RD3_rep2","data_TRUB1_rep2")
# test <- list(data_WT_R1, data_WT_R2,
#              data_PUS10_R1, data_PUS10_R2)

# names(test) <-list("gr1_rep1", "gr2_rep1",
#                    "gr1_rep2", "gr2_rep2")
# names(test) <-list("WT_rep1", "PUS10_rep1",
#                    "WT_rep2", "PUS10_rep2")
# test



getSpikeInCounts(data_gr, si_pattern = "spike", ncores = 1)

getSpikeInNFs(data_gr, si_pattern = "spike", ctrl_pattern = "WT", ncores = 1)

norm_SRPMC <- spikeInNormGRanges(data_gr, si_pattern = "spike", ctrl_pattern = "WT", method = "SRPMC")
norm_SNR <- spikeInNormGRanges(data_gr, si_pattern = "spike", ctrl_pattern = "WT", method = "SNR")
norm_RPM <- spikeInNormGRanges(data_gr, si_pattern = "spike", ctrl_pattern = "WT", method = "RPM")

names(data_gr) <- c("data_WT_rep1","data_PUS10_rep1","data_PUS1_rep1","data_PUS3_rep1","data_PUS7_rep1","data_PUS7L_rep1","data_PUSL1_rep1","data_RD1_rep1","data_RD2_rep1","data_RD3_rep1","data_TRUB1_rep1",
                    "data_WT_rep2","data_PUS10_rep2","data_PUS1_rep2","data_PUS3_rep2","data_PUS7_rep2","data_PUS7L_rep2","data_PUSL1_rep2","data_RD1_rep2","data_RD2_rep2","data_RD3_rep2","data_TRUB1_rep2")
nomr_data <- NULL
for(i in seq(1,length(data_gr),1)){
    sample <- names(data_gr)[i]
    print(sample)
    df <- annoGR2DF(norm_SRPMC[[i]])
    df$sample <-  names(data_gr)[i]
    nomr_data <- rbind(nomr_data,df)
  # head(df)
}
nomr_data <- nomr_data %>% dplyr::select(chr,score,sample)
head(nomr_data)
